<?php

return ['name' => 'DisposableBasic'];
