<?php

return [
    'name' => 'DisposableSpecial',
];
