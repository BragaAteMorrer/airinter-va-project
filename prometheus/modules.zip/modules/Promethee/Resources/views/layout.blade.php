<!doctype html>
<html lang="{{ app()->getLocale() }}" data-era="modern">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>@yield('title', __('promethee.operations_centre')) · Prométhée · Air Inter</title>
<link rel="stylesheet" href="{{ asset('promethee-assets/promethee.css') }}">
<link rel="stylesheet" href="{{ asset('promethee-assets/promethee-v2.css') }}">
<link rel="stylesheet" href="{{ asset('promethee-assets/promethee-distinction.css') }}">
<link rel="stylesheet" href="{{ asset('promethee-assets/airinter-eras.css') }}">
<script src="{{ asset('promethee-assets/promethee.js') }}" defer></script>
<script src="{{ asset('promethee-assets/navigation-groups.js') }}" defer></script>
@php
    // Keeping the array out of the @json directive is deliberate: Blade's
    // directive parser stops at the first closing parenthesis it encounters
    // and cannot safely parse the nested array below.
    $prometheeI18n = [
        'locale' => app()->getLocale(),
        'dateLocale' => config('languages.' . app()->getLocale() . '.intl', app()->getLocale()),
        'minitelBoot' => [
            __('promethee_javascript.minitel.directory'),
            __('promethee_javascript.minitel.rule'),
            __('promethee_javascript.minitel.operations_centre'),
            '',
            __('promethee_javascript.minitel.network_link'),
            __('promethee_javascript.minitel.terminal'),
            '',
            __('promethee_javascript.minitel.loading'),
            __('promethee_javascript.minitel.wait'),
        ],
    ];
@endphp
<script>
window.prometheeI18n = @json($prometheeI18n);
</script>
</head>
<body>
<a class="skip" href="#main">{{ __('promethee.skip_to_content') }}</a>
<aside class="sidebar">
<a class="brand" href="{{ route('promethee.dashboard') }}"><span class="brand-logo-shell"><img class="brand-logo" src="{{ $branding['url'] }}" alt="Air Inter"><img class="brand-logo-minitel" src="{{ asset('promethee-assets/logos/air-inter-minitel.png') }}" alt="Air Inter"></span><span class="brand-caption">{{ __('promethee.virtual_airline') }}<br>{{ __('promethee.french_domestic_network') }}</span></a>
<div class="system-name"><span class="eyebrow">{{ __('promethee.operations_centre') }}</span><strong>Prométhée<span class="cursor">_</span></strong><small>{{ __('promethee.airline_slogan') }}</small></div>
@auth
@php($sidebarPilot = Auth::user() ?: new \App\Models\User(['name' => __('promethee.visitor_access'), 'pilot_id' => 'AIR INTER']))
<section class="pilot-space" aria-label="{{ __('promethee.pilot_area') }}">
<span class="pilot-space-label"><i class="status-dot"></i> {{ __('promethee.pilot_area') }}</span>
<a class="pilot-card-link" href="{{ route('promethee.profile') }}" aria-label="{{ __('promethee.open_profile') }}">
<span class="pilot-avatar">
@if($sidebarPilot?->avatar)<img src="{{ $sidebarPilot->avatar->url }}" alt="{{ __('promethee_accessibility.photo_of', ['name' => $sidebarPilot->name]) }}">
@else<img src="{{ $sidebarPilot ? $sidebarPilot->gravatar(96) : asset('promethee-assets/logos/air-inter-1970s.png') }}" alt="{{ __('promethee_accessibility.air_inter_avatar') }}">
@endif
</span>
<span class="pilot-identity"><strong>{{ $sidebarPilot->name }}</strong><small>{{ $sidebarPilot->pilot_id ?: 'ITF---' }}</small><em>{{ $sidebarPilot->rank?->name ?? 'Pilote Air Inter' }}@if($sidebarPilot->home_airport_id) · {{ $sidebarPilot->home_airport_id }}@endif</em></span>
<b class="pilot-open">↗</b>
</a>
<div class="pilot-space-actions"><a href="{{ route('promethee.profile') }}">{{ __('promethee.view_my_profile') }}</a><a href="{{ url('/logout') }}">{{ __('promethee.logout') }}</a></div>
</section>
@else
<section class="pilot-space" aria-label="{{ __('promethee.visitor_access') }}"><span class="pilot-space-label"><i class="status-dot"></i> {{ __('promethee.visitor_access') }}</span><span class="pilot-identity"><strong>{{ __('promethee.public_report') }}</strong><small>Air Inter VA</small><em>{{ __('promethee.read_only') }}</em></span><div class="pilot-space-actions"><a href="{{ route('login') }}">{{ __('promethee.login') }}</a><a href="{{ route('register') }}">{{ __('promethee.register') }}</a></div></section>
@endauth
<nav aria-label="Navigation principale">
@auth
@foreach(['dashboard'=>['01','dashboard'],'operations'=>['02','operations'],'flights'=>['03','flight_schedule'],'missions'=>['04','missions_circuits'],'assignments'=>['05','assignments'],'shop'=>['06','shop'],'transfers'=>['07','transfers'],'jumpseat'=>['08','jumpseat'],'acars'=>['09','acars'],'calendar'=>['10','calendar'],'pilots'=>['11','community'],'passport'=>['12','passport'],'pireps'=>['13','latest_pireps'],'safety'=>['14','flight_safety']] as $key=>$item)
@if($key === 'pireps')
<a @class(['nav-link','selected'=>request()->routeIs('promethee.pireps.*')]) href="{{ route('promethee.public.pireps') }}"><span>{{ $item[0] }}</span>{{ __('promethee.'.$item[1]) }}<b>↗</b></a>
@else
<a @class(['nav-link','selected'=>request()->routeIs('promethee.'.$key)]) href="{{ route('promethee.'.$key) }}"><span>{{ $item[0] }}</span>{{ __('promethee.'.$item[1]) }}<b>↗</b></a>
@endif
@endforeach
@ability('admin','admin-access')
<a @class(['nav-link','selected'=>request()->routeIs('admin.promethee.*')]) href="{{ route('admin.promethee.dashboard') }}"><span>11</span>{{ __('promethee.administration') }}<b>↗</b></a>
@endability
@else
<a class="nav-link" href="{{ route('promethee.occ') }}"><span>01</span>{{ __('promethee.public_home') }}<b>↗</b></a>
<a class="nav-link" href="{{ route('promethee.public.pireps') }}"><span>02</span>{{ __('promethee.completed_flights') }}<b>↗</b></a>
@endauth
</nav>
</aside>
<div class="workspace">
<header class="topbar"><span class="breadcrumb">AIR INTER <span>/</span> PROMÉTHÉE <span>/</span> @yield('title','EXPLOITATION')</span>
<label class="theme-control">{{ __('promethee.language') }} <select aria-label="{{ __('promethee.language') }}" onchange="if(this.value) window.location=this.value">@foreach(config('languages') as $code=>$language)<option value="{{ route('promethee.language',$code) }}" @selected(app()->getLocale() === $code)>{{ $language['display'] }}</option>@endforeach</select></label>
<label class="theme-control">{{ __('promethee.display') }} <select id="era" aria-label="{{ __('promethee.display_style') }}"><option value="modern">{{ __('promethee.modern') }}</option><option value="2000">{{ __('promethee.year_2000') }}</option><option value="minitel">{{ __('promethee.minitel') }}</option></select></label>
<time id="utc-clock">UTC</time></header>
<main id="main">
@if(session('success'))<div class="notice success" role="status">{{ session('success') }}</div>@endif
@if($errors->any())<div class="notice error" role="alert"><strong>{{ __('promethee.input_error') }}</strong><ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>@endif
@yield('content')
</main>
<footer class="footer"><span>AIR INTER · PROMÉTHÉE</span><span>{{ __('promethee.airline_simulation') }} · {{ date('Y') }}</span><span class="tricolor"><i></i><i></i><i></i></span></footer>
</div>
@stack('scripts')
</body></html>
