<?php
namespace Modules\Promethee\Http;
use App\Contracts\Controller;
use App\Models\{Airline,Airport,Award,Flight,Pirep,User,Fare,Subfleet,Rank};
use App\Models\Enums\{FlightType,PirepState,UserState};
use Carbon\CarbonImmutable;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\File;
use App\Services\AirportService;
use App\Services\FinanceService;
use App\Support\Money;
use Modules\Promethee\Services\{BrandingService,BulletinService,EconomyService,FlightOpsService,SafetyAnalyzer};

class PortalController extends Controller
{
    private function page(string $name, array $data=[]) {
        return view('promethee::'.$name, $data + ['branding' => app(BrandingService::class)->active()]);
    }
    /** Public, read-only OCC overview. No pilot-only fields are exposed here. */
    public function occ() {
        return view('promethee::occ', [
            'pilots' => User::where('state', UserState::ACTIVE)->orderByDesc('created_at')->limit(8)->get(['id','name','pilot_id','home_airport_id','created_at']),
            'completed' => Pirep::where('state', PirepState::ACCEPTED)->with('user:id,name,pilot_id')->latest('submitted_at')->limit(8)->get(),
            'active' => Pirep::whereIn('state', [PirepState::IN_PROGRESS, PirepState::PAUSED])->with('user:id,name,pilot_id')->latest('updated_at')->limit(8)->get(),
        ]);
    }
    public function publicPilots(Request $r) {
        $term = trim((string) $r->query('q'));
        $pilots = User::with(['rank','home_airport'])->whereIn('state',[UserState::ACTIVE,UserState::ON_LEAVE])->when($term,fn($q)=>$q->where(fn($q)=>$q->where('name','like','%'.$term.'%')->orWhere('pilot_id','like','%'.$term.'%')))->orderBy('pilot_id')->paginate(30)->withQueryString();
        $latest = Pirep::where('state', PirepState::ACCEPTED)->whereIn('user_id', $pilots->getCollection()->pluck('id'))->latest('submitted_at')->get()->unique('user_id')->keyBy('user_id');
        $pilots->getCollection()->each(fn (User $pilot) => $pilot->setRelation('latest_public_pirep', $latest->get($pilot->id)));
        return view('promethee::public-pilots', compact('pilots'));
    }
    public function publicPireps(Request $r) {
        $filters = $r->validate([
            'pilot' => 'nullable|string|max:80',
            'flight' => 'nullable|string|max:32',
            'departure' => 'nullable|string|max:8',
            'arrival' => 'nullable|string|max:8',
            'aircraft' => 'nullable|string|max:32',
            'from' => 'nullable|date',
            'to' => 'nullable|date|after_or_equal:from',
        ]);
        $pireps = Pirep::with(['user:id,name,pilot_id','aircraft','airline'])->where('state', PirepState::ACCEPTED)
            ->when($r->filled('pilot'), fn ($q) => $q->whereHas('user', fn ($users) => $users->where('name', 'like', '%'.$filters['pilot'].'%')->orWhere('pilot_id', 'like', '%'.$filters['pilot'].'%')))
            ->when($r->filled('flight'), fn ($q) => $q->where(fn ($reports) => $reports->where('flight_number', 'like', '%'.strtoupper($filters['flight']).'%')->orWhere('route_code', 'like', '%'.strtoupper($filters['flight']).'%')))
            ->when($r->filled('departure'), fn ($q) => $q->where('dpt_airport_id', strtoupper($filters['departure'])))
            ->when($r->filled('arrival'), fn ($q) => $q->where('arr_airport_id', strtoupper($filters['arrival'])))
            ->when($r->filled('aircraft'), fn ($q) => $q->whereHas('aircraft', fn ($aircraft) => $aircraft->where('registration', 'like', '%'.strtoupper($filters['aircraft']).'%')->orWhere('icao', 'like', '%'.strtoupper($filters['aircraft']).'%')))
            ->when($r->filled('from'), fn ($q) => $q->whereDate('submitted_at', '>=', $filters['from']))
            ->when($r->filled('to'), fn ($q) => $q->whereDate('submitted_at', '<=', $filters['to']))
            ->latest('submitted_at')->paginate(30)->withQueryString();

        return $this->page('public-pireps', compact('pireps'));
    }
    /** The branded, public replacement for /legacy/pireps/{id}. */
    public function pirep(string $id) {
        $pirep = Pirep::with([
            'acars', 'acars_logs', 'acars_route', 'aircraft.airline', 'airline',
            'arr_airport', 'dpt_airport', 'alt_airport', 'fares', 'field_values',
            'flight', 'simbrief', 'user.rank', 'comments.user',
        ])->findOrFail($id);

        return $this->page('pirep', ['pirep' => $pirep]);
    }
    public function publicLive() { return view('promethee::public-live'); }

    /**
     * Return the next departure occurrence in Paris time.
     *
     * phpVMS schedules are recurring rather than dated.  Sorting their raw
     * HH:MM values made the dispatch board call flights from this morning
     * "upcoming" for the rest of the day.  A trailing Z explicitly denotes a
     * UTC time; otherwise the historic Air Inter timetable is Paris local time.
     */
    private function nextDeparture(Flight $flight): ?CarbonImmutable {
        $raw = trim((string) $flight->dpt_time);
        if (!preg_match('/^(\d{1,2}):(\d{2})(Z)?$/i', $raw, $parts)) return null;

        $timezone = !empty($parts[3]) ? 'UTC' : 'Europe/Paris';
        $now = CarbonImmutable::now('Europe/Paris');
        $base = $now->setTimezone($timezone)->startOfDay();
        $hour = (int) $parts[1];
        $minute = (int) $parts[2];
        $days = (int) ($flight->days ?? 0);

        for ($offset = 0; $offset <= 7; $offset++) {
            $departure = $base->addDays($offset)->setTime($hour, $minute);
            $parisDeparture = $departure->setTimezone('Europe/Paris');
            $operatesThatDay = $days === 0 || ($days & (1 << $parisDeparture->dayOfWeek));

            if ($operatesThatDay && $parisDeparture->greaterThan($now)) return $parisDeparture;
        }

        return null;
    }

    private function month(Request $r): string {
        $r->validate(['month'=>'nullable|date_format:Y-m']);
        return $r->query('month',now('Europe/Paris')->format('Y-m'));
    }
    private function operationsData(Request $r): array {
        $dayStart = now('Europe/Paris')->startOfDay()->utc();
        $dayEnd = now('Europe/Paris')->endOfDay()->utc();
        $monthStart = now('Europe/Paris')->startOfMonth()->utc();
        $homeAirportId = $r->user()->home_airport_id;
        return [
            'activeFlights'=>Pirep::whereIn('state',[PirepState::IN_PROGRESS,PirepState::PAUSED])->count(),
            'pendingPireps'=>Pirep::where('state',PirepState::PENDING)->count(),
            'acceptedToday'=>Pirep::where('state',PirepState::ACCEPTED)->whereBetween('submitted_at',[$dayStart,$dayEnd])->count(),
            'acceptedMonth'=>Pirep::where('state',PirepState::ACCEPTED)->where('submitted_at','>=',$monthStart)->count(),
            'telemetrySamples'=>DB::table('promethee_telemetry')->where('created_at','>=',$dayStart)->count(),
            'pricingRules'=>DB::table('promethee_pricing')->count(),
            'lastBulletin'=>DB::table('promethee_bulletins')->orderByDesc('month')->first(),
            // The dashboard is a pilot dispatch board: show departures from the
            // pilot's assigned base only. A pilot without a base must not see a
            // misleading, network-wide list.
            'upcoming'=>Flight::where('active',true)
                ->where('visible',true)
                // A bid reserves a published line. The board is for flights
                // that are still available to reserve.
                ->where('has_bid',false)
                ->when($homeAirportId,
                    fn ($flights) => $flights->where('dpt_airport_id',$homeAirportId),
                    fn ($flights) => $flights->whereRaw('1 = 0')
                )
                ->with(['airline','fares','arr_airport'])
                ->get()
                ->map(function (Flight $flight) {
                    $nextDeparture = $this->nextDeparture($flight);
                    $flight->setAttribute('next_departure_at', $nextDeparture);
                    $flight->setAttribute('display_departure_time', $nextDeparture?->format('H:i'));
                    return $flight;
                })
                ->filter(fn (Flight $flight) => $flight->next_departure_at !== null)
                ->sortBy('next_departure_at')
                ->take(10)
                ->values(),
            'homeAirportId'=>$homeAirportId,
            'recentPireps'=>Pirep::where('state',PirepState::ACCEPTED)->with(['airline','aircraft'])->orderByDesc('submitted_at')->limit(8)->get(),
            'topRoutes'=>Pirep::select('dpt_airport_id','arr_airport_id',DB::raw('COUNT(*) as total'))
                ->where('state',PirepState::ACCEPTED)->where('submitted_at','>=',$monthStart)
                ->groupBy('dpt_airport_id','arr_airport_id')->orderByDesc('total')->limit(8)->get(),
            'events'=>DB::table('promethee_events')->where('ends_at','>=',now())->orderBy('starts_at')->limit(4)->get(),
            'personal'=>Pirep::where('user_id',$r->user()->id)->where('state',PirepState::ACCEPTED)->count(),
        ];
    }
    public function dashboard(Request $r) {
        return $this->page('dashboard',[
            'flightCount'=>Flight::where('active',true)->count(),
            'pilotCount'=>User::where('state',UserState::ACTIVE)->count(),
            'pirepCount'=>Pirep::where('state',PirepState::ACCEPTED)->where('submitted_at','>=',now()->startOfMonth())->count(),
            'flights'=>Flight::where('active',true)->with('airline')->orderBy('dpt_time')->limit(7)->get(),
            'events'=>DB::table('promethee_events')->where('ends_at','>=',now())->orderBy('starts_at')->limit(3)->get(),
            'personal'=>Pirep::where('user_id',$r->user()->id)->where('state',PirepState::ACCEPTED)->count(),
        ] + $this->operationsData($r));
    }
    public function operations(Request $r) {
        return $this->page('operations',$this->operationsData($r));
    }
    public function catalogue(Request $r, string $type = 'flights') {
        abort_unless(in_array($type,['flights','airports'],true),404);
        $filters=$r->validate(['country'=>'nullable|string|size:2','region'=>'nullable|string|max:32','airline_id'=>'nullable|integer|exists:airlines,id','status'=>'nullable|in:all,active,inactive','flight_type'=>'nullable|string|size:1','arrival_country'=>'nullable|string|size:2','min_distance'=>'nullable|numeric|min:0','max_distance'=>'nullable|numeric|gte:min_distance','schedule'=>'nullable|in:all,defined,missing','fuel'=>'nullable|in:all,custom,default','coordinates'=>'nullable|in:all,complete,missing','q'=>'nullable|string|max:80']);
        $country=strtoupper($filters['country'] ?? ''); $term=$filters['q'] ?? '';
        $countries=Airport::whereNotNull('country')->where('country','!=','')->distinct()->orderBy('country')->pluck('country');
        $regions=Airport::whereNotNull('region')->where('region','!=','')->select('country','region')->distinct()->orderBy('country')->orderBy('region')->get();
        if ($type==='airports') {
            $items=Airport::query()->when($country,fn($query)=>$query->where('country',$country))->when($r->filled('region'),fn($query)=>$query->where('region',$filters['region']))->when(($filters['fuel'] ?? 'all')==='custom',fn($query)=>$query->where('fuel_jeta_cost','>',0))->when(($filters['fuel'] ?? 'all')==='default',fn($query)=>$query->where(fn($q)=>$q->whereNull('fuel_jeta_cost')->orWhere('fuel_jeta_cost','<=',0)))->when(($filters['coordinates'] ?? 'all')==='complete',fn($query)=>$query->whereNotNull('lat')->whereNotNull('lon'))->when(($filters['coordinates'] ?? 'all')==='missing',fn($query)=>$query->where(fn($q)=>$q->whereNull('lat')->orWhereNull('lon')))->when($term,fn($query)=>$query->where(fn($q)=>$q->where('id','like','%'.$term.'%')->orWhere('icao','like','%'.$term.'%')->orWhere('name','like','%'.$term.'%')->orWhere('location','like','%'.$term.'%')))->orderBy('country')->orderBy('region')->orderBy('location')->orderBy('name')->paginate(40)->withQueryString();
        } else {
            $items=Flight::with('airline')->when($country,fn($query)=>$query->whereHas('dpt_airport',fn($airports)=>$airports->where('country',$country)))->when($r->filled('region'),fn($query)=>$query->whereHas('dpt_airport',fn($airports)=>$airports->where('region',$filters['region'])))->when($r->filled('arrival_country'),fn($query)=>$query->whereHas('arr_airport',fn($airports)=>$airports->where('country',$filters['arrival_country'])))->when($r->filled('airline_id'),fn($query)=>$query->where('airline_id',$filters['airline_id']))->when(($filters['status'] ?? 'all')!=='all',fn($query)=>$query->where('active',$filters['status']==='active'))->when($r->filled('flight_type'),fn($query)=>$query->where('flight_type',$filters['flight_type']))->when($r->filled('min_distance'),fn($query)=>$query->where('distance','>=',$filters['min_distance']))->when($r->filled('max_distance'),fn($query)=>$query->where('distance','<=',$filters['max_distance']))->when(($filters['schedule'] ?? 'all')==='defined',fn($query)=>$query->whereNotNull('dpt_time'))->when(($filters['schedule'] ?? 'all')==='missing',fn($query)=>$query->whereNull('dpt_time'))->when($term,fn($query)=>$query->where(fn($q)=>$q->where('flight_number','like','%'.$term.'%')->orWhere('dpt_airport_id','like','%'.$term.'%')->orWhere('arr_airport_id','like','%'.$term.'%')->orWhere('route_code','like','%'.$term.'%')))->orderBy('dpt_airport_id')->orderBy('arr_airport_id')->paginate(40)->withQueryString();
        }
        return $this->page('catalogue',['type'=>$type,'items'=>$items,'countries'=>$countries,'regions'=>$regions,'airlines'=>Airline::where('active',true)->orderBy('name')->get(['id','name']),'flightTypes'=>Flight::where('active',true)->distinct()->orderBy('flight_type')->pluck('flight_type')]);
    }
    public function live(Request $r) { return $this->page('live'); }
    public function liveData(Request $r, FlightOpsService $ops) {
        $pireps=Pirep::whereIn('state',[PirepState::IN_PROGRESS,PirepState::PAUSED])->with('user')->orderByDesc('updated_at')->limit(50)->get();
        return response()->json(['updated_at'=>now()->toIso8601String(),'flights'=>$pireps->map(function ($p) use ($ops) {
            $sample=DB::table('promethee_telemetry')->where('pirep_id',$p->id)->latest('recorded_at')->first(); $data=$sample ? json_decode($sample->payload,true) : [];
            return $ops->liveFlight(['id'=>$p->id,'ident'=>$p->ident,'pilot'=>$p->user?->name,'departure'=>$p->dpt_airport_id,'arrival'=>$p->arr_airport_id,'state'=>PirepState::label($p->state),'recorded_at'=>$sample?->recorded_at,'lat'=>$data['lat']??null,'lon'=>$data['lon']??null,'altitude'=>$data['altitude_msl']??null,'ias'=>$data['ias']??null,'gs'=>$data['gs']??null,'vs'=>$data['vs']??null,'heading'=>$data['heading']??null,'fuel'=>$data['fuel']??null,'on_ground'=>$data['on_ground']??null],$data);
        })]);
    }
    public function profile(Request $r) {
        return $this->pilot($r->user()->id);
    }
    /**
     * Pilot passport. A country is stamped after an accepted flight touching
     * one of its airports; no editable or duplicate passport data is stored.
     */
    public function passport(Request $r) {
        $pilot = $r->user();
        // Raw aggregates are not handled by Laravel's table-prefix grammar.
        // Build the actual configured airport table name explicitly instead.
        $airportCountry = DB::getTablePrefix().'airports.country';
        $countries = DB::query()->fromSub(
            Pirep::query()->selectRaw('dpt_airport_id as airport_id, submitted_at as stamped_at')
                ->where('user_id', $pilot->id)->where('state', PirepState::ACCEPTED)
                ->unionAll(Pirep::query()->selectRaw('arr_airport_id as airport_id, submitted_at as stamped_at')
                    ->where('user_id', $pilot->id)->where('state', PirepState::ACCEPTED)),
            'stamps'
        )->join('airports', 'airports.id', '=', 'stamps.airport_id')
            ->whereNotNull('airports.country')->where('airports.country', '!=', '')
            // Do not qualify stamped_at here: phpVMS prefixes derived-table
            // aliases (for example phpvms7_stamps), while raw SQL is not
            // rewritten by Laravel's table-prefix grammar.
            ->select('airports.country', DB::raw('MIN(stamped_at) as first_visit'), DB::raw('MAX(stamped_at) as last_visit'), DB::raw('COUNT(*) as legs'))
            ->groupBy('airports.country')->orderBy('airports.country')->get();

        $ranking = DB::query()->fromSub(
            Pirep::query()->select('user_id', 'dpt_airport_id as airport_id')->where('state', PirepState::ACCEPTED)
                ->unionAll(Pirep::query()->select('user_id', 'arr_airport_id as airport_id')->where('state', PirepState::ACCEPTED)),
            'passport_legs'
        )->join('airports', 'airports.id', '=', 'passport_legs.airport_id')
            ->join('users', 'users.id', '=', 'passport_legs.user_id')
            ->whereNotNull('airports.country')->where('airports.country', '!=', '')
            ->select('users.id', 'users.name', 'users.pilot_id', DB::raw('COUNT(DISTINCT '.$airportCountry.') as countries'))
            ->groupBy('users.id', 'users.name', 'users.pilot_id')->orderByDesc('countries')->orderBy('users.pilot_id')->limit(20)->get();

        abort_unless(DB::table('promethee_settings')->where('key','passport.enabled')->value('value') !== '0', 404);
        return $this->page('passport', compact('pilot', 'countries', 'ranking'));
    }
    /** Current missions and circuits. Completion is derived from accepted PIREPs. */
    public function missions(Request $r) {
        $today = today('Europe/Paris')->toDateString(); $userId = $r->user()->id;
        $reports = Pirep::where('user_id',$userId)->where('state',PirepState::ACCEPTED)
            ->get(['id','flight_id','dpt_airport_id','arr_airport_id','submitted_at']);
        $matches = function ($item) use ($reports) {
            return $reports->first(fn ($report) =>
                (!$item->flight_id || (string)$report->flight_id === (string)$item->flight_id) &&
                (!$item->dpt_airport_id || $report->dpt_airport_id === $item->dpt_airport_id) &&
                (!$item->arr_airport_id || $report->arr_airport_id === $item->arr_airport_id)
            );
        };
        $missions = DB::table('promethee_missions')->where('active',true)
            ->where(fn($q)=>$q->whereNull('starts_on')->orWhere('starts_on','<=',$today))
            ->where(fn($q)=>$q->whereNull('ends_on')->orWhere('ends_on','>=',$today))->orderBy('ends_on')->get()
            ->map(function ($mission) use ($matches) { $mission->completion = $matches($mission); return $mission; });
        $circuits = DB::table('promethee_circuits')->where('active',true)
            ->where(fn($q)=>$q->whereNull('starts_on')->orWhere('starts_on','<=',$today))
            ->where(fn($q)=>$q->whereNull('ends_on')->orWhere('ends_on','>=',$today))->orderBy('ends_on')->get()
            ->map(function ($circuit) use ($matches) { $circuit->legs=DB::table('promethee_circuit_legs')->where('circuit_id',$circuit->id)->orderBy('position')->get()->map(function($leg) use($matches){ $leg->completion=$matches($leg); return $leg; }); $circuit->completed=$circuit->legs->isNotEmpty() && $circuit->legs->every(fn($leg)=>$leg->completion); return $circuit; });
        return $this->page('missions', compact('missions','circuits'));
    }
    public function assignments(Request $r) {
        $month=$r->query('month',now('Europe/Paris')->format('Y-m'));
        abort_unless((bool)preg_match('/^\\d{4}-(0[1-9]|1[0-2])$/',$month),422,'Mois invalide.');
        $assignments=DB::table('promethee_assignments as assignment')->join('flights','flights.id','=','assignment.flight_id')->where('assignment.user_id',$r->user()->id)->where('assignment.month',$month)->select('assignment.*','flights.route_code','flights.flight_number','flights.dpt_airport_id','flights.arr_airport_id')->get();
        $completed=Pirep::where('user_id',$r->user()->id)->where('state',PirepState::ACCEPTED)->whereIn('flight_id',$assignments->pluck('flight_id'))->pluck('flight_id')->flip();
        $assignments->each(fn($assignment)=>$assignment->completed=$completed->has($assignment->flight_id));
        return $this->page('assignments',compact('assignments','month'));
    }
    public function shop(Request $r) { $wallet=$r->user()->journal->getBalance(); $items=DB::table('promethee_shop_items')->where('active',true)->orderBy('price')->get(); $orders=DB::table('promethee_shop_orders as orders')->join('promethee_shop_items as items','items.id','=','orders.item_id')->where('orders.user_id',$r->user()->id)->select('orders.*','items.name')->latest('purchased_at')->get(); return $this->page('shop',compact('wallet','items','orders')); }
    public function buyShopItem(int $id, Request $r, FinanceService $finance) { return DB::transaction(function() use($id,$r,$finance) { $item=DB::table('promethee_shop_items')->where('id',$id)->where('active',true)->lockForUpdate()->first(); abort_unless($item,404); $user=$r->user()->fresh('journal'); if((int)$user->journal->getBalance()->getAmount() < (int)$item->price) return back()->withErrors(['shop'=>'Solde phpVMS insuffisant.']); $finance->debitFromJournal($user->journal,new Money($item->price),$user,'Boutique : '.$item->name,'shop','shop'); DB::table('promethee_shop_orders')->insert(['user_id'=>$user->id,'item_id'=>$item->id,'price'=>$item->price,'purchased_at'=>now(),'created_at'=>now(),'updated_at'=>now()]); return back()->with('success','Achat enregistré dans votre journal phpVMS.'); }); }
    public function transfers(Request $r) { return $this->page('transfers',['requests'=>DB::table('promethee_transfer_requests')->where('user_id',$r->user()->id)->latest()->get(),'airlines'=>Airline::where('active',true)->orderBy('name')->get(['id','name']),'hubs'=>Airport::where('hub',true)->orderBy('id')->get(['id','name'])]); }
    /** Same formula as the historical Prometheus jumpseat: configurable base per nautical mile. */
    private function jumpseatQuote(User $user, Airport $destination): array {
        $originId = $user->curr_airport_id ?: $user->home_airport_id;
        $origin = Airport::findOrFail($originId);
        $distance = app(AirportService::class)->calculateDistance($origin->id, $destination->id)->toUnit('nmi', 2);
        $discount = (float) setting('dbasic.jumpseat_discount', 0);
        $ratio = $discount > 0 && $discount < 100 ? 1 - ($discount / 100) : 1;
        $basePrice = (float) (DB::table('promethee_settings')->where('key', 'jumpseat.base_price')->value('value') ?: 0.13);
        $amount = Money::createFromAmount(round($basePrice * $distance * $ratio, 2));

        return compact('origin', 'distance', 'discount', 'amount');
    }
    public function jumpseat(Request $r) {
        $pilot = $r->user()->load('journal');
        $origin = Airport::find($pilot->curr_airport_id ?: $pilot->home_airport_id);
        return $this->page('jumpseat',[
            'airports'=>Airport::orderBy('country')->orderBy('icao')->get(['id','icao','name','location','country']),
            'origin'=>$origin,
            'basePrice'=>(float) (DB::table('promethee_settings')->where('key', 'jumpseat.base_price')->value('value') ?: 0.13),
            'discount'=>(float) setting('dbasic.jumpseat_discount', 0),
            'wallet'=>$pilot->journal->getBalance(),
            'orders'=>DB::table('promethee_transfer_requests as request')->join('airports','airports.id','=','request.target_airport_id')->where('request.user_id',$pilot->id)->where('request.type','jumpseat')->select('request.*','airports.icao','airports.name as airport_name')->latest('request.created_at')->get()
        ]);
    }
    public function requestJumpseat(Request $r, FinanceService $finance) {
        $data=$r->validate(['target_airport_id'=>'required|string|exists:airports,id','reason'=>'nullable|string|max:2000']);
        return DB::transaction(function() use($data,$r,$finance) {
            $user=User::with(['journal','airline.journal'])->findOrFail($r->user()->id);
            $airport=Airport::findOrFail($data['target_airport_id']);
            $originId=$user->curr_airport_id ?: $user->home_airport_id;
            if (!$originId) return back()->withErrors(['jumpseat'=>'Votre aéroport actuel est introuvable.']);
            if ($originId === $airport->id) return back()->withErrors(['jumpseat'=>'Vous êtes déjà positionné à cet aéroport.']);
            $quote=$this->jumpseatQuote($user,$airport);
            if ($r->boolean('preview')) return back()->with('success','Tarif du jumpseat : '.$quote['origin']->icao.' → '.$airport->icao.' · '.$quote['distance'].' NM · '.$quote['amount'].'.');
            if((int)$user->journal->getBalance()->getAmount() < (int)$quote['amount']->getAmount()) return back()->withErrors(['jumpseat'=>'Solde phpVMS insuffisant pour ce jumpseat ('.$quote['amount'].').']);
            $finance->debitFromJournal($user->journal,$quote['amount'],$user,'Jumpseat '.$quote['origin']->icao.' > '.$airport->icao,'jumpseat','jumpseat');
            if ($user->airline?->journal) $finance->creditToJournal($user->airline->journal,$quote['amount'],$user,'Jumpseat de '.$user->name.' ('.$quote['origin']->icao.' > '.$airport->icao.')','jumpseat','jumpseat');
            $user->update(['curr_airport_id'=>$airport->id]);
            DB::table('promethee_transfer_requests')->insert(['user_id'=>$user->id,'type'=>'jumpseat','target_airport_id'=>$airport->id,'reason'=>$data['reason']??null,'status'=>'approved','decision_note'=>'Déplacement automatique : '.$quote['distance'].' NM, remise '.$quote['discount'].' %, montant '.$quote['amount'].'.','decided_at'=>now(),'created_at'=>now(),'updated_at'=>now()]);
            return back()->with('success','Jumpseat effectué : '.$quote['origin']->icao.' → '.$airport->icao.' ('.$quote['distance'].' NM, '.$quote['amount'].').');
        });
    }
    public function requestTransfer(Request $r, FinanceService $finance) { $data=$r->validate(['type'=>'required|in:airline,hub,jumpseat','target_airline_id'=>'nullable|required_if:type,airline|required_if:type,jumpseat|exists:airlines,id','target_airport_id'=>'nullable|required_if:type,hub|exists:airports,id','reason'=>'nullable|string|max:2000']); if($data['type']==='jumpseat') return DB::transaction(function() use($data,$r,$finance) { $user=$r->user()->fresh('journal'); $price=(int)(DB::table('promethee_settings')->where('key','jumpseat.price')->value('value') ?: 2500); if((int)$user->journal->getBalance()->getAmount()<$price)return back()->withErrors(['transfer'=>'Solde phpVMS insuffisant pour le jumpseat.']); $airline=Airline::findOrFail($data['target_airline_id']); $finance->debitFromJournal($user->journal,new Money($price),$user,'Jumpseat : '.$airline->name,'jumpseat','jumpseat'); DB::table('promethee_transfer_requests')->insert(['user_id'=>$user->id,'type'=>'jumpseat','target_airline_id'=>$airline->id,'reason'=>$data['reason']??null,'status'=>'approved','decision_note'=>'Accord automatique après paiement.','decided_at'=>now(),'created_at'=>now(),'updated_at'=>now()]); return back()->with('success','Jumpseat accordé et débité de votre journal phpVMS.'); }); DB::table('promethee_transfer_requests')->insert(['user_id'=>$r->user()->id,'type'=>$data['type'],'target_airline_id'=>$data['target_airline_id']??null,'target_airport_id'=>$data['target_airport_id']??null,'reason'=>$data['reason']??null,'status'=>'pending','created_at'=>now(),'updated_at'=>now()]); return back()->with('success','Demande de transfert transmise au staff.'); }
    public function flights(Request $r) {
        $filters = $r->validate([
            'departure'   => 'nullable|string|max:8',
            'arrival'     => 'nullable|string|max:8',
            'airline_id'  => 'nullable|integer|exists:airlines,id',
            'subfleet_id' => 'nullable|integer|exists:subfleets,id',
            'flight_type' => 'nullable|string|size:1',
            'q'           => 'nullable|string|max:32',
            'min_distance'=> 'nullable|numeric|min:0',
            'max_distance'=> 'nullable|numeric|gte:min_distance',
            'time_from'   => 'nullable|date_format:H:i',
            'time_to'     => 'nullable|date_format:H:i',
            'sort'        => 'nullable|in:departure,ident,distance',
        ]);

        $q = Flight::where('active', true)->where('visible', true)->with(['airline', 'fares', 'dpt_airport', 'arr_airport', 'subfleets']);
        if ($r->filled('departure')) $q->where('dpt_airport_id', strtoupper($filters['departure']));
        if ($r->filled('arrival')) $q->where('arr_airport_id', strtoupper($filters['arrival']));
        if ($r->filled('airline_id')) $q->where('airline_id', $filters['airline_id']);
        if ($r->filled('subfleet_id')) $q->whereHas('subfleets', fn ($subfleets) => $subfleets->where('subfleets.id', $filters['subfleet_id']));
        if ($r->filled('flight_type')) $q->where('flight_type', $filters['flight_type']);
        if ($r->filled('min_distance')) $q->where('distance', '>=', $filters['min_distance']);
        if ($r->filled('max_distance')) $q->where('distance', '<=', $filters['max_distance']);
        if ($r->filled('time_from')) $q->where('dpt_time', '>=', $filters['time_from']);
        if ($r->filled('time_to')) $q->where('dpt_time', '<=', $filters['time_to']);
        if ($r->filled('q')) {
            $term = '%'.strtoupper($filters['q']).'%';
            $q->where(function ($flights) use ($term) {
                $flights->where('flight_number', 'like', $term)
                    ->orWhere('callsign', 'like', $term)
                    ->orWhere('route_code', 'like', $term)
                    ->orWhere('dpt_airport_id', 'like', $term)
                    ->orWhere('arr_airport_id', 'like', $term);
            });
        }

        $sort = $filters['sort'] ?? 'departure';
        if ($sort === 'ident') $q->orderBy('route_code')->orderBy('flight_number');
        elseif ($sort === 'distance') $q->orderBy('distance');
        else $q->orderBy('dpt_time')->orderBy('route_code')->orderBy('flight_number');

        $airportIds = Flight::where('active', true)->where('visible', true)
            ->select('dpt_airport_id as id')->union(
                Flight::where('active', true)->where('visible', true)->select('arr_airport_id as id')
            );
        $mapAirports = Airport::whereIn('id', $airportIds)->orderBy('icao')->get(['id', 'icao', 'name', 'location', 'lat', 'lon']);
        $bounds = [
            'west' => $mapAirports->min('lon') ?? -10,
            'east' => $mapAirports->max('lon') ?? 10,
            'north' => $mapAirports->max('lat') ?? 55,
            'south' => $mapAirports->min('lat') ?? 40,
        ];
        $lonSpan = max(1, $bounds['east'] - $bounds['west']);
        $latSpan = max(1, $bounds['north'] - $bounds['south']);
        $mapAirports = $mapAirports->map(fn ($airport) => [
            'code' => $airport->id,
            'name' => $airport->name,
            'location' => $airport->location,
            'lat' => (float) $airport->lat,
            'lon' => (float) $airport->lon,
            'x' => round(35 + (($airport->lon - $bounds['west']) / $lonSpan) * 930, 1),
            'y' => round(35 + (($bounds['north'] - $airport->lat) / $latSpan) * 470, 1),
        ]);
        $mapByCode = $mapAirports->keyBy('code');
        $mapRoutes = collect();
        if ($r->filled('departure') || $r->filled('arrival')) {
            $mapRoutes = (clone $q)->reorder()->select('dpt_airport_id', 'arr_airport_id')->distinct()->limit(160)->get()
                ->map(fn ($flight) => ['from' => $mapByCode->get($flight->dpt_airport_id), 'to' => $mapByCode->get($flight->arr_airport_id)])
                ->filter(fn ($route) => $route['from'] && $route['to'])->values();
        }

        return $this->page('flights', [
            'flights' => $q->paginate(24)->withQueryString(),
            'airlines' => Airline::where('active', true)->orderBy('name')->get(['id', 'name', 'icao']),
            'subfleets' => Subfleet::with('airline')->orderBy('name')->get(['id', 'name', 'type', 'airline_id']),
            'flightTypes' => Flight::where('active', true)->where('visible', true)->distinct()->orderBy('flight_type')->pluck('flight_type')
                ->mapWithKeys(fn ($type) => [$type => FlightType::label($type)]),
            'mapAirports' => $mapAirports,
            'mapRoutes' => $mapRoutes,
        ]);
    }
    public function flight(string $id) {
        $flight = Flight::with(['airline','fares','subfleets','dpt_airport','arr_airport','alt_airport'])->findOrFail($id);
        $stats = [
            'pireps'=>Pirep::where('flight_id',$flight->id)->where('state',PirepState::ACCEPTED)->count(),
            'last'=>Pirep::where('flight_id',$flight->id)->where('state',PirepState::ACCEPTED)->orderByDesc('submitted_at')->first(),
        ];
        $history=Pirep::where('flight_id',$flight->id)->where('state',PirepState::ACCEPTED);
        $routeHistory=['flights'=>(clone $history)->count(),'average_time'=>(int) (clone $history)->avg('flight_time'),'best_time'=>(int) (clone $history)->min('flight_time')];
        $weather=[];
        try {
            $service=app(\App\Services\AirportService::class);
            foreach (array_filter([$flight->dpt_airport_id,$flight->arr_airport_id,$flight->alt_airport_id]) as $icao) {
                $weather[$icao]=['metar'=>$service->getMetar($icao)?->raw,'taf'=>$service->getTaf($icao)?->raw];
            }
        } catch (\Throwable) { }
        return $this->page('flight',['flight'=>$flight,'stats'=>$stats,'routeHistory'=>$routeHistory,'weather'=>$weather, 'recentPireps'=>Pirep::with(['user','aircraft'])->where('flight_id',$flight->id)->where('state',PirepState::ACCEPTED)->latest('submitted_at')->limit(12)->get(), 'reservation'=>DB::table('bids')->where(['flight_id'=>$flight->id,'user_id'=>auth()->id()])->first()]);
    }
    public function reserveFlight(string $id, Request $r, \App\Services\BidService $bids) {
        $flight=Flight::where(['id'=>$id,'active'=>true,'visible'=>true])->firstOrFail();
        try { $bids->addBid($flight,$r->user()); return back()->with('success','Vol '.$flight->ident.' réservé.'); }
        catch (\Throwable $e) { return back()->withErrors(['reservation'=>$e->getMessage() ?: 'Cette réservation ne peut pas être créée.']); }
    }
    public function briefing(string $id, Request $r) {
        $flight=Flight::with(['airline','dpt_airport','arr_airport','alt_airport','subfleets'])->findOrFail($id);
        $weather=[];
        try {
            $service=app(\App\Services\AirportService::class);
            foreach (array_filter([$flight->dpt_airport_id,$flight->arr_airport_id,$flight->alt_airport_id]) as $icao) {
                $weather[$icao]=['metar'=>$service->getMetar($icao)?->raw,'taf'=>$service->getTaf($icao)?->raw];
            }
        } catch (\Throwable) { }
        $distance=(float) $flight->distance->toUnit('nmi');
        $fuelUnit=setting('units.fuel', 'kg');
        // The dispatch rule is calculated in kilograms, then converted to the
        // unit selected for this installation before it is shown to the pilot.
        $suggestedFuel=(int) round(\App\Support\Units\Fuel::make(ceil(max(250,$distance*3.2)), 'kg')->toUnit($fuelUnit));
        $briefing=DB::table('promethee_briefings')->where(['user_id'=>$r->user()->id,'flight_id'=>$flight->id])->first();
        return $this->page('briefing',['flight'=>$flight,'weather'=>$weather,'briefing'=>$briefing,'suggestedFuel'=>$suggestedFuel,'fuelUnit'=>$fuelUnit]);
    }
    public function saveBriefing(string $id, Request $r) {
        Flight::findOrFail($id);
        $data=$r->validate(['ofp_reference'=>'nullable|string|max:120','alternate'=>'nullable|string|max:8','planned_fuel'=>'nullable|integer|min:0|max:1000000','notes'=>'nullable|string|max:4000']);
        if (!empty($data['alternate'])) $data['alternate']=strtoupper($data['alternate']);
        DB::table('promethee_briefings')->updateOrInsert(['user_id'=>$r->user()->id,'flight_id'=>$id],$data+['updated_at'=>now(),'created_at'=>now()]);
        DB::table('promethee_audit_logs')->insert(['actor_id'=>$r->user()->id,'action'=>'briefing.saved','subject_type'=>'flight','subject_id'=>$id,'context'=>json_encode(['ofp_reference'=>$data['ofp_reference']??null]),'created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','Briefing enregistré. L’OFP reste une référence pilote : il n’est pas transmis à un service tiers.');
    }
    public function replay(string $id) {
        $pirep=Pirep::with(['user','aircraft','flight'])->findOrFail($id);
        $samples=DB::table('promethee_telemetry')->where('pirep_id',$id)->orderBy('recorded_at')->get()->map(fn ($row) => array_merge(json_decode($row->payload,true),['recorded_at'=>$row->recorded_at]))->values();
        $score=(new SafetyAnalyzer())->score($pirep->landing_rate === null ? null : (float) $pirep->landing_rate,$samples->all());
        return $this->page('replay',['pirep'=>$pirep,'samples'=>$samples,'analysis'=>$score['analysis'],'score'=>$score]);
    }
    public function calendar(Request $r) {
        $month=$this->month($r);
        $start=CarbonImmutable::createFromFormat('!Y-m',$month,'Europe/Paris');
        $events=DB::table('promethee_events')->where('starts_at','<',$start->addMonth()->utc())
            ->where('ends_at','>=',$start->utc())->orderBy('starts_at')->get();
        $rsvps=DB::table('promethee_event_rsvps')->whereIn('event_id',$events->pluck('id'))->select('event_id',DB::raw('COUNT(*) as total'))->groupBy('event_id')->pluck('total','event_id');
        $mine=DB::table('promethee_event_rsvps')->where('user_id',$r->user()->id)->whereIn('event_id',$events->pluck('id'))->pluck('status','event_id');
        $events=$events->map(function ($event) use ($rsvps,$mine) { $event->rsvp_count=$rsvps[$event->id]??0; $event->my_rsvp=$mine[$event->id]??null; return $event; });
        return $this->page('calendar',[
            'month'=>$month,'start'=>$start,
            'events'=>$events,
        ]);
    }
    public function rsvpEvent(int $id, Request $r) {
        DB::table('promethee_events')->find($id) ?? abort(404);
        $data=$r->validate(['status'=>'required|in:going,maybe']);
        DB::table('promethee_event_rsvps')->updateOrInsert(['event_id'=>$id,'user_id'=>$r->user()->id],$data+['updated_at'=>now(),'created_at'=>now()]);
        return back()->with('success','Participation enregistrée.');
    }
    public function saveEvent(Request $r) {
        $d=$r->validate(['title'=>'required|string|max:191','description'=>'nullable|string|max:4000',
            'starts_at'=>'required|date','ends_at'=>'required|date|after:starts_at',
            'departure'=>'nullable|exists:airports,id','arrival'=>'nullable|exists:airports,id']);
        foreach (['starts_at','ends_at'] as $key) $d[$key]=CarbonImmutable::parse($d[$key],'Europe/Paris')->utc();
        DB::table('promethee_events')->insert($d+['created_by'=>$r->user()->id,'created_at'=>now(),'updated_at'=>now()]);
        return redirect()->route('promethee.calendar',['month'=>$d['starts_at']->setTimezone('Europe/Paris')->format('Y-m')])->with('success','Événement ajouté au calendrier.');
    }
    public function deleteEvent(int $id) {
        DB::table('promethee_events')->where('id',$id)->delete();
        return back()->with('success','Événement supprimé.');
    }
    public function adminEvents() {
        return $this->page('admin.events', ['events' => DB::table('promethee_events')->orderByDesc('starts_at')->get()]);
    }
    public function saveAdminEvent(Request $r) {
        $d=$r->validate(['event_id'=>'nullable|integer|exists:promethee_events,id','title'=>'required|string|max:191','description'=>'nullable|string|max:4000',
            'starts_at'=>'required|date','ends_at'=>'required|date|after:starts_at','departure'=>'nullable|exists:airports,id','arrival'=>'nullable|exists:airports,id']);
        foreach (['starts_at','ends_at'] as $key) $d[$key]=CarbonImmutable::parse($d[$key],'Europe/Paris')->utc();
        $id=$d['event_id'] ?? null; unset($d['event_id']);
        if ($id) DB::table('promethee_events')->where('id',$id)->update($d+['updated_at'=>now()]);
        else DB::table('promethee_events')->insert($d+['created_by'=>$r->user()->id,'created_at'=>now(),'updated_at'=>now()]);
        return redirect()->route('admin.promethee.events')->with('success',$id ? 'Événement mis à jour.' : 'Événement ajouté au calendrier.');
    }
    public function pilots(Request $r) {
        $r->validate(['status'=>'nullable|in:actif,ancien,retraite','q'=>'nullable|string|max:80','airline_id'=>'nullable|integer|exists:airlines,id','rank_id'=>'nullable|integer|exists:ranks,id']);
        $status=$r->query('status','actif');
        $q=User::query()->with(['rank','airline']);
        // A pilote en congé reste membre de la communauté : il ne doit pas disparaître de l'annuaire.
        if ($status==='actif') $q->whereIn('state',[UserState::ACTIVE,UserState::ON_LEAVE])->whereNotIn('id',DB::table('promethee_members')->whereIn('status',['ancien','retraite'])->select('user_id'));
        else $q->whereIn('id',DB::table('promethee_members')->where('status',$status)->select('user_id'));
        if ($r->filled('q')) {
            $term='%'.$r->query('q').'%';
            $q->where(fn ($pilots) => $pilots->where('name','like',$term)->orWhere('email','like',$term)->orWhere('pilot_id','like',$term));
        }
        if ($r->filled('airline_id')) $q->where('airline_id',$r->query('airline_id'));
        if ($r->filled('rank_id')) $q->where('rank_id',$r->query('rank_id'));
        return $this->page('pilots',[
            'pilots'=>$q->orderBy('pilot_id')->paginate(24)->withQueryString(),
            'status'=>$status,
            'airlines'=>Airline::orderBy('name')->get(['id','name','icao']),
            'ranks'=>Rank::orderBy('hours')->orderBy('name')->get(['id','name']),
        ]);
    }
    public function pilot(int $id) {
        $pilot = User::with(['rank','airline','home_airport','current_airport','journal'])->withCount([
            'pireps as accepted_pireps_count' => fn ($q) => $q->where('state',PirepState::ACCEPTED),
            'bids as bids_count',
        ])->findOrFail($id);
        $pireps = Pirep::where('user_id',$pilot->id)->where('state',PirepState::ACCEPTED)
            ->with(['airline','aircraft'])->orderByDesc('submitted_at')->paginate(15)->withQueryString();
        $routes = Pirep::select('dpt_airport_id','arr_airport_id',DB::raw('COUNT(*) as total'))
            ->where('user_id',$pilot->id)->where('state',PirepState::ACCEPTED)
            ->groupBy('dpt_airport_id','arr_airport_id')->orderByDesc('total')->limit(8)->get();
        $monthFlights=Pirep::where('user_id',$pilot->id)->where('state',PirepState::ACCEPTED)->where('submitted_at','>=',now()->startOfMonth())->count();
        $badges=collect([['name'=>'Premier officier','description'=>'10 vols validés','earned'=>$pilot->accepted_pireps_count>=10],['name'=>'Régularité','description'=>'3 vols ce mois','earned'=>$monthFlights>=3],['name'=>'Grand voyageur','description'=>'50 heures de vol','earned'=>($pilot->flight_time??0)>=3000]]);
        $badges=$pilot->awards()->orderBy('name')->get();
        // Older/imported pilot accounts may not yet have a phpVMS journal.
        // A profile remains read-only in that case and reports a zero balance.
        $wallet = $pilot->journal?->getBalance() ?? new Money(0);

        return $this->page('profile',['pilot'=>$pilot,'wallet'=>$wallet,'pireps'=>$pireps,'routes'=>$routes,'monthFlights'=>$monthFlights,'badges'=>$badges]);
    }
    public function saveMember(int $id,Request $r) {
        User::findOrFail($id);
        $d=$r->validate(['status'=>'required|in:actif,ancien,retraite']);
        DB::table('promethee_members')->updateOrInsert(['user_id'=>$id],$d+['updated_at'=>now(),'created_at'=>now()]);
        return back()->with('success','Classement mis à jour. Le compte et le carnet de vol sont conservés.');
    }
    public function economy(Request $r) {
        $flightFilters=$r->validate(['flight_airline'=>'nullable|string|max:10','flight_origin'=>'nullable|string|size:2','flight_arrival'=>'nullable|string|size:2','flight_dpt_airport'=>'nullable|string|max:10','flight_arr_airport'=>'nullable|string|max:10','flight_search'=>'nullable|string|max:80','flight_select_all'=>'nullable|boolean']);
        $fuelFilters=$r->validate(['fuel_country'=>'nullable|string|size:2','fuel_region'=>'nullable|string|max:191','fuel_search'=>'nullable|string|max:80','fuel_select_all'=>'nullable|boolean']);
        $airportOptions=Airport::select('id','icao','name','country','region','location')->orderBy('country')->orderBy('region')->orderBy('location')->get();
        $flightPricing=Flight::where('active',true)
            ->when($flightFilters['flight_airline'] ?? null,fn($query,$icao)=>$query->whereHas('airline',fn($airline)=>$airline->where('icao',$icao)))
            ->when($flightFilters['flight_origin'] ?? null,fn($query,$country)=>$query->whereHas('dpt_airport',fn($airport)=>$airport->where('country',$country)))
            ->when($flightFilters['flight_arrival'] ?? null,fn($query,$country)=>$query->whereHas('arr_airport',fn($airport)=>$airport->where('country',$country)))
            ->when($flightFilters['flight_dpt_airport'] ?? null,fn($query,$airport)=>$query->where('dpt_airport_id',$airport))
            ->when($flightFilters['flight_arr_airport'] ?? null,fn($query,$airport)=>$query->where('arr_airport_id',$airport))
            ->when($flightFilters['flight_search'] ?? null,fn($query,$search)=>$query->where(fn($where)=>$where->where('flight_number','like','%'.$search.'%')->orWhere('route_code','like','%'.$search.'%')->orWhere('dpt_airport_id','like','%'.$search.'%')->orWhere('arr_airport_id','like','%'.$search.'%')))
            ->with(['airline','fares','dpt_airport','arr_airport'])
            ->orderBy('airline_id')->orderBy('dpt_airport_id')->orderBy('arr_airport_id')->get();
        $fuelPricing=Airport::select('id','icao','name','country','region','fuel_jeta_cost','fuel_100ll_cost','fuel_mogas_cost')
            ->when($fuelFilters['fuel_country'] ?? null,fn($query,$country)=>$query->where('country',$country))
            ->when($fuelFilters['fuel_region'] ?? null,fn($query,$region)=>$query->where('region',$region))
            ->when($fuelFilters['fuel_search'] ?? null,fn($query,$search)=>$query->where(fn($where)=>$where->where('country','like','%'.$search.'%')->orWhere('region','like','%'.$search.'%')))
            ->orderBy('country')->orderBy('region')->orderBy('icao')->get();
        $scopeFromAirports=function($airports, string $country, ?string $region) {
            $display=function(string $field) use ($airports) {
                $prices=$airports->pluck($field)->filter(fn($price)=>$price !== null && $price !== '')->unique()->values();
                return $prices->count() === 1 ? $prices->first() : ($prices->isEmpty() ? 'Défaut' : 'Variés');
            };
            return (object)['country'=>$country,'region'=>$region,'count'=>$airports->count(),'jeta'=>$display('fuel_jeta_cost'),'100ll'=>$display('fuel_100ll_cost'),'mogas'=>$display('fuel_mogas_cost')];
        };
        $fuelScopes=collect();
        foreach ($fuelPricing->filter(fn($airport)=>preg_match('/^[A-Z]{2}$/',strtoupper((string)$airport->country)))->groupBy('country') as $country=>$countryAirports) {
            $fuelScopes->push($scopeFromAirports($countryAirports,$country,null));
            foreach ($countryAirports->filter(fn($airport)=>filled($airport->region))->groupBy('region') as $region=>$regionAirports) $fuelScopes->push($scopeFromAirports($regionAirports,$country,$region));
        }
        return $this->page('economy',['fares'=>Fare::where('active',true)->get(),'airlines'=>Airline::all(),
            'history'=>DB::table('promethee_changes')->orderByDesc('id')->limit(15)->get(),
            'priceHistory'=>DB::table('promethee_price_history')->latest()->limit(120)->get(),
            'pricingRules'=>DB::table('promethee_pricing_rules')->orderBy('priority')->orderByDesc('id')->get(),
            'diagnostics'=>$this->pricingDiagnostics(),'seasons'=>DB::table('promethee_seasons')->orderByDesc('starts_on')->get(['id','name','starts_on','ends_on','active']),
            'subfleets'=>Subfleet::with('airline')->orderBy('name')->get(['id','name','airline_id','type']),
            'preview'=>$r->session()->get('promethee.preview'),'bandSettings'=>$this->bandSettings(),'airportOptions'=>$airportOptions,
            'flightPricing'=>$flightPricing,'fuelPricing'=>$fuelPricing,'fuelScopes'=>$fuelScopes,'flightFilters'=>$flightFilters,'fuelFilters'=>$fuelFilters,'flightSelectAll'=>$r->boolean('flight_select_all'),'fuelSelectAll'=>$r->boolean('fuel_select_all'),
            'baseFares'=>Fare::whereIn('code',['Y','T','CGO'])->get()->keyBy('code'),'baseFareDefaults'=>$this->fareDefaults(),
            'pricingBands'=>DB::table('promethee_pricing')->get()->mapWithKeys(fn($row)=>[$row->flight_id.'|'.$row->fare_id=>$row->band]),
            'loadFactor'=>(float)(DB::table('promethee_settings')->where('key','pricing.simulation.load_factor')->value('value') ?: 70),
            'countries'=>$airportOptions->pluck('country')->filter()->unique()->sort()->values(),
            'regions'=>$airportOptions->filter(fn($airport)=>filled($airport->region))->map(fn($airport)=>['country'=>$airport->country,'region'=>$airport->region])->unique()->values()]);
    }
    public function flightPriceEditor(Request $r) {
        $airportOptions=Airport::select('id','icao','name','country','region')->orderBy('country')->orderBy('icao')->get();
        $flightPricing=Flight::where('active',true)->with(['airline','fares','dpt_airport','arr_airport'])
            ->orderBy('airline_id')->orderBy('dpt_airport_id')->orderBy('arr_airport_id')->get();
        return $this->page('economy-flight-prices',[
            'airlines'=>Airline::orderBy('name')->get(),
            'airportOptions'=>$airportOptions,
            'countries'=>$airportOptions->pluck('country')->filter()->unique()->sort()->values(),
            'flightPricing'=>$flightPricing,
            'baseFares'=>Fare::whereIn('code',['Y','T','CGO'])->get()->keyBy('code'),'baseFareDefaults'=>$this->fareDefaults(),
            'pricingBands'=>DB::table('promethee_pricing')->get()->mapWithKeys(fn($row)=>[$row->flight_id.'|'.$row->fare_id=>$row->band]),
            'selectedFlights'=>collect($r->query('flights',[]))->push($r->query('flight'))->filter()->map(fn($id)=>(string)$id)->unique()->values()->all(),
        ]);
    }
    public function flightPriceEdit(string $flight) {
        $flight=Flight::with(['airline','fares','dpt_airport','arr_airport'])->findOrFail($flight);
        $fareCode=$flight->airline?->icao === 'ICS' ? 'CGO' : ($flight->airline?->icao === 'ACF' ? 'T' : 'Y');
        $baseFare=Fare::withTrashed()->where('code',$fareCode)->first();
        $defaultPrices=['Y'=>218.0,'T'=>352.0,'CGO'=>1.5];
        $fare=$flight->fares->first() ?: $baseFare;
        $price=(float)($fare?->pivot?->price ?: $fare?->price ?: $defaultPrices[$fareCode]);
        return $this->page('economy-flight-price-edit',[
            'flight'=>$flight,'fare'=>$fare,'fareCode'=>$fareCode,'price'=>$price,
            'band'=>$fare ? (DB::table('promethee_pricing')->where('flight_id',$flight->id)->where('fare_id',$fare->id)->value('band') ?: 'rouge') : 'rouge',
        ]);
    }
    public function fuelPriceEdit(Request $r, string $country) {
        $region=$r->query('region');
        $airports=Airport::where('country',strtoupper($country))->when($region,fn($query)=>$query->where('region',$region))->orderBy('icao')->get();
        abort_if($airports->isEmpty(),404);
        $price=function(string $field) use ($airports) {
            $values=$airports->pluck($field)->filter(fn($value)=>$value !== null && $value !== '')->unique()->values();
            return $values->count() === 1 ? (float)$values->first() : null;
        };
        return $this->page('economy-fuel-price-edit',['country'=>strtoupper($country),'region'=>$region,'airportCount'=>$airports->count(),'prices'=>['fuel_jeta_cost'=>$price('fuel_jeta_cost'),'fuel_100ll_cost'=>$price('fuel_100ll_cost'),'fuel_mogas_cost'=>$price('fuel_mogas_cost')]]);
    }
    public function fuelPriceEditor(Request $r) {
        $airports=Airport::select('id','country','region')->orderBy('country')->orderBy('region')->get();
        $scopes=$airports->filter(fn($airport)=>preg_match('/^[A-Z]{2}$/',strtoupper((string)$airport->country)))->groupBy(fn($airport)=>$airport->country.'|'.$airport->region)->map(function($items) {
            $first=$items->first();
            return (object)['key'=>$first->country.'|'.$first->region,'country'=>$first->country,'region'=>$first->region,'count'=>$items->count()];
        })->values();
        return $this->page('economy-fuel-price-editor',['scopes'=>$scopes,'countries'=>$airports->pluck('country')->filter()->unique()->sort()->values(),'regions'=>$airports->map(fn($airport)=>['country'=>$airport->country,'region'=>$airport->region])->filter(fn($row)=>filled($row['region']))->unique(fn($row)=>$row['country'].'|'.$row['region'])->values(),'selectedScopes'=>collect($r->query('scopes',[]))->map(fn($key)=>(string)$key)->all()]);
    }
    private function pricingDiagnostics(): array {
        $alerts=[];
        $defaultFuel=Airport::where(fn($q)=>$q->whereNull('fuel_jeta_cost')->orWhere('fuel_jeta_cost','<=',0))->count();
        if ($defaultFuel) $alerts[]=['level'=>'info','title'=>'Tarif Jet A par défaut','count'=>$defaultFuel,'detail'=>'aéroport(s) utilisent le prix carburant global de phpVMS.'];
        $coordinates=Airport::whereNull('lat')->orWhereNull('lon')->count();
        if ($coordinates) $alerts[]=['level'=>'warning','title'=>'Coordonnées manquantes','count'=>$coordinates,'detail'=>'aéroport(s) ne pourront pas être placés correctement sur les cartes.'];
        $invalidFlights=Flight::where(fn($q)=>$q->whereDoesntHave('dpt_airport')->orWhereDoesntHave('arr_airport'))->count();
        if ($invalidFlights) $alerts[]=['level'=>'danger','title'=>'Lignes à corriger','count'=>$invalidFlights,'detail'=>'ligne(s) référencent un aéroport absent.'];
        $noCabin=Flight::where('active',true)->whereDoesntHave('subfleets.fares')->count();
        if ($noCabin) $alerts[]=['level'=>'warning','title'=>'Cabine manquante','count'=>$noCabin,'detail'=>'ligne(s) actives ne proposent aucune cabine tarifaire.'];
        return $alerts;
    }
    private function bandSettings(): array {
        return ['enabled'=>DB::table('promethee_settings')->where('key','pricing.bands.enabled')->value('value') !== '0','blue'=>(float)(DB::table('promethee_settings')->where('key','pricing.bands.blue')->value('value') ?: 50),'white'=>(float)(DB::table('promethee_settings')->where('key','pricing.bands.white')->value('value') ?: 75)];
    }
    private function fareDefaults(): array {
        return ['Y'=>['name'=>'Air Inter Economy','price'=>218.0], 'T'=>['name'=>'Air Charter International','price'=>352.0], 'CGO'=>['name'=>'Inter Cargo Service','price'=>1.5]];
    }
    public function saveBandSettings(Request $r) {
        $data=$r->validate(['enabled'=>'nullable|boolean','blue'=>'required|numeric|between:1,100','white'=>'required|numeric|between:1,100']);
        foreach (['enabled'=>$r->boolean('enabled') ? '1' : '0','blue'=>(string)$data['blue'],'white'=>(string)$data['white']] as $key=>$value) DB::table('promethee_settings')->updateOrInsert(['key'=>'pricing.bands.'.$key],['value'=>$value,'updated_at'=>now(),'created_at'=>now()]);
        return back()->with('success','Profil Bleu-Blanc-Rouge enregistré.');
    }
    public function saveSimulationSettings(Request $r) {
        $data=$r->validate(['load_factor'=>'required|numeric|between:1,100']);
        DB::table('promethee_settings')->updateOrInsert(['key'=>'pricing.simulation.load_factor'],['value'=>(string)$data['load_factor'],'created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','Taux de remplissage de simulation enregistré.');
    }
    public function savePricingRule(Request $r) {
        $data=$r->validate(['name'=>'required|string|max:120','target'=>'required|in:ticket,fuel','country'=>'nullable|string|size:2','region'=>'nullable|string|max:191','airline_id'=>'nullable|exists:airlines,id','subfleet_id'=>'nullable|exists:subfleets,id','arrival_country'=>'nullable|string|size:2','distance_min'=>'nullable|numeric|min:0','distance_max'=>'nullable|numeric|gte:distance_min','season_id'=>'nullable|exists:promethee_seasons,id','fare_id'=>'nullable|exists:fares,id','fuel_type'=>'nullable|in:fuel_jeta_cost,fuel_100ll_cost,fuel_mogas_cost','mode'=>'required|in:percent,add,set','value'=>'required|numeric|between:-999999,999999','band'=>'nullable|in:keep,bleu,blanc,rouge','blue_percent'=>'nullable|numeric|between:1,100','white_percent'=>'nullable|numeric|between:1,100','priority'=>'required|integer|between:1,255','active'=>'nullable|boolean']);
        if ($data['target']==='ticket' && empty($data['fare_id'])) return back()->withErrors(['fare_id'=>'Une cabine est requise pour une règle billet.'])->withInput();
        if ($data['target']==='fuel' && empty($data['fuel_type'])) return back()->withErrors(['fuel_type'=>'Un type de carburant est requis.'])->withInput();
        $data['airport_id']=$r->validate(['airport_id'=>'nullable|exists:airports,id'])['airport_id'] ?? null;
        $definition=array_filter($data,fn($value,$key)=>!in_array($key,['name','priority','active'],true) && $value!==null && $value!=='',ARRAY_FILTER_USE_BOTH);
        $definition += ['band'=>'keep','blue_percent'=>$this->bandSettings()['blue'],'white_percent'=>$this->bandSettings()['white'],'fuel_type'=>'fuel_jeta_cost'];
        DB::table('promethee_pricing_rules')->insert(['user_id'=>$r->user()->id,'name'=>$data['name'],'target'=>$data['target'],'definition'=>json_encode($definition),'active'=>$r->boolean('active'),'priority'=>$data['priority'],'created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','Règle tarifaire enregistrée. Elle ne modifie rien tant que sa simulation n’est pas confirmée.');
    }
    public function updatePricingRule(int $id, Request $r) {
        $data=$r->validate(['name'=>'required|string|max:120','target'=>'required|in:ticket,fuel','country'=>'nullable|string|size:2','region'=>'nullable|string|max:191','airport_id'=>'nullable|exists:airports,id','airline_id'=>'nullable|exists:airlines,id','subfleet_id'=>'nullable|exists:subfleets,id','arrival_country'=>'nullable|string|size:2','distance_min'=>'nullable|numeric|min:0','distance_max'=>'nullable|numeric|gte:distance_min','season_id'=>'nullable|exists:promethee_seasons,id','fare_id'=>'nullable|exists:fares,id','fuel_type'=>'nullable|in:fuel_jeta_cost,fuel_100ll_cost,fuel_mogas_cost','mode'=>'required|in:percent,add,set','value'=>'required|numeric|between:-999999,999999','band'=>'nullable|in:keep,bleu,blanc,rouge','blue_percent'=>'nullable|numeric|between:1,100','white_percent'=>'nullable|numeric|between:1,100','priority'=>'required|integer|between:1,255','active'=>'nullable|boolean']);
        if ($data['target']==='ticket' && empty($data['fare_id'])) return back()->withErrors(['fare_id'=>'Une cabine est requise pour une règle billet.'])->withInput();
        if ($data['target']==='fuel' && empty($data['fuel_type'])) return back()->withErrors(['fuel_type'=>'Un type de carburant est requis.'])->withInput();
        $definition=array_filter($data,fn($value,$key)=>!in_array($key,['name','priority','active'],true) && $value!==null && $value!=='',ARRAY_FILTER_USE_BOTH);
        $definition += ['band'=>'keep','blue_percent'=>$this->bandSettings()['blue'],'white_percent'=>$this->bandSettings()['white'],'fuel_type'=>'fuel_jeta_cost'];
        DB::table('promethee_pricing_rules')->where('id',$id)->update(['name'=>$data['name'],'target'=>$data['target'],'definition'=>json_encode($definition),'active'=>$r->boolean('active'),'priority'=>$data['priority'],'updated_at'=>now()]);
        return back()->with('success','Règle tarifaire mise à jour. Simulez-la avant de publier les changements.');
    }
    public function previewPricingRule(int $id, Request $r, EconomyService $service) {
        $rule=DB::table('promethee_pricing_rules')->where('id',$id)->where('active',true)->first(); abort_unless($rule,404);
        $definition=(array)json_decode($rule->definition,true);
        if (!empty($definition['season_id'])) { $season=DB::table('promethee_seasons')->find($definition['season_id']); abort_unless($season,422,'Saison introuvable.'); abort_if(today()->lt($season->starts_on)||today()->gt($season->ends_on),422,'Cette règle est hors de sa saison active.'); }
        $r->session()->put('promethee.preview',$service->preview($definition)+['expires'=>time()+900,'rule_id'=>$rule->id]);
        DB::table('promethee_pricing_rules')->where('id',$id)->update(['last_previewed_at'=>now(),'updated_at'=>now()]);
        return redirect()->to(route('admin.promethee.economy').'#preview');
    }
    public function deletePricingRule(int $id) { DB::table('promethee_pricing_rules')->where('id',$id)->delete(); return back()->with('success','Règle supprimée.'); }
    public function importPricing(Request $r, EconomyService $service) {
        $data=$r->validate(['pricing_file'=>'required|file|mimes:csv,txt|max:2048']); $handle=fopen($data['pricing_file']->getRealPath(),'r');
        $first=fgets($handle); rewind($handle); $delimiter=substr_count((string)$first,';')>=substr_count((string)$first,',') ? ';' : ','; $header=fgetcsv($handle,0,$delimiter) ?: []; $header=array_map(fn($v)=>strtolower(trim(preg_replace('/^\xEF\xBB\xBF/','',$v))),$header);
        $required=['target','id','field','price']; abort_unless(!array_diff($required,$header),422,'Colonnes requises : target;id;field;price;band (facultatif).'); $items=[]; $line=1;
        while (($row=fgetcsv($handle,0,$delimiter))!==false) { $line++; if (!array_filter($row,fn($v)=>trim((string)$v)!=='')) continue; $raw=array_combine($header,array_pad($row,count($header),null)); $target=strtolower(trim($raw['target'])); $field=trim($raw['field']);
            if (!in_array($target,['fuel','ticket'],true)) abort(422,"Ligne {$line} : target doit être fuel ou ticket.");
            if ($target==='fuel' && !in_array($field,['fuel_jeta_cost','fuel_100ll_cost','fuel_mogas_cost'],true)) abort(422,"Ligne {$line} : champ carburant invalide.");
            if ($target==='ticket' && (!ctype_digit($field) || !in_array(strtolower($raw['band'] ?? 'rouge'),['bleu','blanc','rouge'],true))) abort(422,"Ligne {$line} : field doit être l’ID cabine et band bleu/blanc/rouge.");
            if (!is_numeric($raw['price'])) abort(422,"Ligne {$line} : prix invalide."); $items[$line]=['target'=>$target,'id'=>trim($raw['id']),'field'=>$field,'fare_id'=>$target==='ticket' ? (int)$field : null,'price'=>(float)$raw['price'],'band'=>$target==='ticket' ? strtolower($raw['band'] ?? 'rouge') : null];
        } fclose($handle); $r->session()->put('promethee.preview',$service->importPreview($items)+['expires'=>time()+900]); return redirect()->to(route('admin.promethee.economy').'#preview');
    }
    public function cancelPreview(Request $r) { $r->session()->forget('promethee.preview'); return redirect()->route('admin.promethee.economy')->with('success','Aperçu annulé : aucune modification n’a été appliquée.'); }
    public function mailbox(Request $r) {
        $messages=DB::table('promethee_messages')->where(function ($query) use ($r) {$query->where('recipient_id',$r->user()->id)->orWhere('sender_id',$r->user()->id)->orWhere('shared_staff',true);})->latest()->paginate(30);
        return $this->page('mailbox',['messages'=>$messages,'pilots'=>User::whereIn('state',[UserState::ACTIVE,UserState::ON_LEAVE])->orderBy('pilot_id')->get(['id','name','email','pilot_id']),'activeCount'=>User::where('state',UserState::ACTIVE)->count(),'staffCount'=>User::whereRoleIs('admin')->count()]);
    }
    public function sendMessage(Request $r) {
        $data=$r->validate(['audience'=>'required|in:user,active,staff','user_id'=>'required_if:audience,user|nullable|exists:users,id','subject'=>'required|string|max:191','body'=>'required|string|max:10000','shared_staff'=>'nullable|boolean']);
        $recipients=match($data['audience']) { 'user'=>User::whereKey($data['user_id'])->get(), 'active'=>User::where('state',UserState::ACTIVE)->get(), 'staff'=>User::whereRoleIs('admin')->get() };
        abort_if($recipients->isEmpty(),422,'Aucun destinataire pour ce groupe.');
        foreach ($recipients as $recipient) { $id=DB::table('promethee_messages')->insertGetId(['sender_id'=>$r->user()->id,'recipient_id'=>$recipient->id,'recipient_email'=>$recipient->email,'audience'=>$data['audience'],'subject'=>$data['subject'],'body'=>$data['body'],'shared_staff'=>$r->boolean('shared_staff') || $data['audience']==='staff','direction'=>'outbound','status'=>'queued','created_at'=>now(),'updated_at'=>now()]); try { Mail::raw($data['body'],fn($mail)=>$mail->to($recipient->email,$recipient->name)->subject($data['subject'])); DB::table('promethee_messages')->where('id',$id)->update(['status'=>'sent','sent_at'=>now(),'updated_at'=>now()]); } catch (\Throwable) { DB::table('promethee_messages')->where('id',$id)->update(['status'=>'failed','updated_at'=>now()]); } }
        return back()->with('success',$recipients->count().' message(s) préparé(s) pour envoi. Consultez le statut dans la boîte partagée.');
    }
    public function network() {
        $monthStart=now()->startOfMonth();
        $monthCounts=DB::table('pireps')->select('flight_id',DB::raw('COUNT(*) as total'))->where('state',PirepState::ACCEPTED)->where('submitted_at','>=',$monthStart)->groupBy('flight_id');
        $totalCounts=DB::table('pireps')->select('flight_id',DB::raw('COUNT(*) as total'))->where('state',PirepState::ACCEPTED)->groupBy('flight_id');
        // The query builder prefixes subquery aliases, while raw SQL
        // fragments are left untouched. Keep both references aligned.
        $prefix=DB::getTablePrefix();
        $monthAlias=$prefix.'month_counts';
        $totalAlias=$prefix.'total_counts';
        $flights=Flight::where('flights.active',true)->where('flights.visible',true)->with('airline')
            ->leftJoinSub($monthCounts,'month_counts',fn ($join) => $join->on('flights.id','=','month_counts.flight_id'))
            ->leftJoinSub($totalCounts,'total_counts',fn ($join) => $join->on('flights.id','=','total_counts.flight_id'))
            ->select('flights.*',DB::raw("COALESCE(`{$monthAlias}`.`total`,0) as month_pireps"),DB::raw("COALESCE(`{$totalAlias}`.`total`,0) as total_pireps"))
            ->orderByDesc('month_pireps')->limit(100)->get();
        return $this->page('network',['flights'=>$flights,'season'=>DB::table('promethee_seasons')->where('active',true)->first(),'subfleets'=>Subfleet::with('airline')->orderBy('type')->get(),'imports'=>DB::table('promethee_audit_logs')->where('action','schedule.imported')->latest()->limit(10)->get()]);
    }
    public function health() {
        $latest=DB::table('promethee_telemetry')->latest('recorded_at')->first();
        return $this->page('health',['latestTelemetry'=>$latest,'audit'=>DB::table('promethee_audit_logs')->latest()->limit(30)->get(),'tables'=>['Télémétrie'=>DB::table('promethee_telemetry')->count(),'Briefings'=>DB::table('promethee_briefings')->count(),'Événements'=>DB::table('promethee_events')->count(),'Saisons'=>DB::table('promethee_seasons')->count()]]);
    }
    public function seasons(Request $r) {
        return $this->page('seasons',['seasons'=>DB::table('promethee_seasons')->orderByDesc('starts_on')->get()]);
    }
    public function saveSeason(Request $r) {
        $data=$r->validate(['name'=>'required|string|max:80','starts_on'=>'required|date','ends_on'=>'required|date|after:starts_on','notes'=>'nullable|string|max:2000','active'=>'nullable|boolean']);
        if (!empty($data['active'])) DB::table('promethee_seasons')->update(['active'=>false,'updated_at'=>now()]);
        DB::table('promethee_seasons')->insert($data+['active'=>$r->boolean('active'),'created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','Saison enregistrée.');
    }
    public function importSchedule(Request $r) {
        $data=$r->validate(['schedule'=>'required|file|mimes:csv,txt|max:5120']);
        $handle=fopen($data['schedule']->getRealPath(),'r'); $header=fgetcsv($handle,0,';') ?: fgetcsv($handle); $header=array_map(fn ($v)=>strtolower(trim($v)),$header ?: []);
        $required=['airline_id','flight_number','departure','arrival']; abort_unless(!array_diff($required,$header),422,'Colonnes CSV requises : airline_id;flight_number;departure;arrival');
        $created=0; $errors=[];
        while (($row=fgetcsv($handle,0,';')) !== false) { $line=array_combine($header,array_pad($row,count($header),null)); try {
            $flight=Flight::firstOrNew(['airline_id'=>(int)$line['airline_id'],'flight_number'=>(int)$line['flight_number'],'dpt_airport_id'=>strtoupper($line['departure']),'arr_airport_id'=>strtoupper($line['arrival'])]);
            $flight->fill(['dpt_time'=>$line['dpt_time']??null,'arr_time'=>$line['arr_time']??null,'route'=>$line['route']??null,'active'=>true,'visible'=>true,'flight_type'=>$line['flight_type']??'J']); $flight->id ??= (string) \Illuminate\Support\Str::uuid(); $flight->save(); $created++;
        } catch (\Throwable $e) { $errors[]='ligne '.($created+count($errors)+2); } }
        fclose($handle); DB::table('promethee_audit_logs')->insert(['actor_id'=>$r->user()->id,'action'=>'schedule.imported','subject_type'=>'schedule','subject_id'=>null,'context'=>json_encode(['created'=>$created,'errors'=>$errors]),'created_at'=>now(),'updated_at'=>now()]); return back()->with('success',"Import : {$created} ligne(s) traitée(s).".(count($errors) ? ' Erreurs : '.implode(', ',$errors) : ''));
    }
    public function changeFlightPrices(Request $r) {
        $data=$r->validate(['flight_ids'=>'required|array|min:1','flight_ids.*'=>'exists:flights,id','mode'=>'required|in:set,add,percent,band','value'=>'nullable|numeric','band'=>'required|in:keep,bleu,blanc,rouge']);
        if ($data['mode'] !== 'band' && !array_key_exists('value',$data)) abort(422,'Une valeur est requise.');
        $bandSettings=$this->bandSettings();
        DB::transaction(function () use ($data,$r,$bandSettings) {
            foreach (Flight::with(['fares','airline'])->whereIn('id',$data['flight_ids'])->lockForUpdate()->get() as $flight) {
                $fares=$flight->fares;
                if ($fares->isEmpty()) {
                    $code=$flight->airline?->icao==='ICS' ? 'CGO' : ($flight->airline?->icao==='ACF' ? 'T' : 'Y');
                    $defaults=['Y'=>['name'=>'Air Inter Economy','type'=>0,'price'=>218], 'T'=>['name'=>'Air Charter International','type'=>0,'price'=>352], 'CGO'=>['name'=>'Inter Cargo Service','type'=>1,'price'=>1.5]];
                    $fare=Fare::withTrashed()->where('code',$code)->first();
                    if ($fare?->trashed()) $fare->restore();
                    $fares=collect([$fare ?: Fare::create(['code'=>$code,'name'=>$defaults[$code]['name'],'type'=>$defaults[$code]['type'],'price'=>$defaults[$code]['price'],'active'=>true])]);
                }
                foreach ($fares as $fare) {
                $current=(float)($fare->pivot?->price ?: $fare->price);
                $pricing=DB::table('promethee_pricing')->where(['flight_id'=>$flight->id,'fare_id'=>$fare->id])->first();
                $oldBand=$pricing->band ?? 'rouge';
                $multipliers=['bleu'=>$bandSettings['blue']/100,'blanc'=>$bandSettings['white']/100,'rouge'=>1];
                $red=(float)($pricing->red_price ?? ($current/$multipliers[$oldBand]));
                $newRed=$data['mode']==='band' ? $red : ($data['mode']==='set' ? (float)$data['value'] : ($data['mode']==='add' ? $red+(float)$data['value'] : $red*(1+(float)$data['value']/100)));
                $band=$data['band']==='keep' ? $oldBand : $data['band'];
                $next=round($newRed*$multipliers[$band],2);
                if ($next<0) abort(422,'Un prix ne peut pas être négatif.');
                DB::table('flight_fare')->updateOrInsert(['flight_id'=>$flight->id,'fare_id'=>$fare->id],['price'=>(string)round($next,2),'updated_at'=>now()]);
                DB::table('promethee_pricing')->updateOrInsert(['flight_id'=>$flight->id,'fare_id'=>$fare->id],['red_price'=>$newRed,'band'=>$band,'multiplier'=>$multipliers[$band],'updated_at'=>now(),'created_at'=>$pricing?->created_at ?? now()]);
                DB::table('promethee_price_history')->insert(['target'=>'ticket','subject_id'=>$flight->id,'field'=>'fare:'.$fare->id,'before_price'=>$current,'after_price'=>$next,'context'=>json_encode(['label'=>$flight->ident,'operation'=>$data['mode'],'value'=>$data['value'] ?? null,'band'=>$band]),'created_at'=>now(),'updated_at'=>now()]);
            }
            }
        });
        return back()->with('success','Prix des lignes sélectionnées mis à jour.');
    }
    public function changeFuelPrices(Request $r) {
        $data=$r->validate(['country'=>'required_without:scope_keys|nullable|string|size:2','region'=>'nullable|string|max:191','scope_keys'=>'nullable|array|min:1','scope_keys.*'=>'string|max:200','fuel_type'=>'required|in:fuel_jeta_cost,fuel_100ll_cost,fuel_mogas_cost','mode'=>'required|in:set,add,percent','value'=>'required|numeric']);
        $scopes=collect($data['scope_keys'] ?? [strtoupper((string)$data['country']).'|'.($data['region'] ?? '')])->filter(function($key) {
            [$country,$region]=array_pad(explode('|',$key,2),2,'');
            return preg_match('/^[A-Z]{2}$/',strtoupper($country));
        })->map(function($key) {
            [$country,$region]=array_pad(explode('|',$key,2),2,'');
            return ['country'=>strtoupper($country),'region'=>$region];
        })->unique(fn($scope)=>$scope['country'].'|'.$scope['region'])->values();
        abort_if($scopes->isEmpty(),422,'Aucun périmètre carburant valide n’a été sélectionné.');
        $count=DB::transaction(function() use ($data,$scopes) {
            $airports=Airport::where(function($query) use ($scopes) { foreach ($scopes as $scope) $query->orWhere(function($where) use ($scope) { $where->where('country',$scope['country']); if ($scope['region'] !== '') $where->where('region',$scope['region']); }); })->lockForUpdate()->get();
            abort_if($airports->isEmpty(),404);
            $defaults=['fuel_jeta_cost'=>'airports.default_jet_a_fuel_cost','fuel_100ll_cost'=>'airports.default_100ll_fuel_cost','fuel_mogas_cost'=>'airports.default_mogas_fuel_cost'];
            $updated=0;
            foreach ($airports as $airport) {
                $before=$airport->getRawOriginal($data['fuel_type']);
                $current=(float)($before ?: setting($defaults[$data['fuel_type']],0));
                $next=$data['mode']==='set' ? (float)$data['value'] : ($data['mode']==='add' ? $current+(float)$data['value'] : $current*(1+(float)$data['value']/100));
                if ($next<=0) {
                    if ($current<=0 && $data['mode']!=='set') continue;
                    abort(422,'Le prix du carburant doit être supérieur à zéro.');
                }
                DB::table('airports')->where('id',$airport->id)->update([$data['fuel_type']=>round($next,4)]);
                DB::table('promethee_price_history')->insert(['target'=>'fuel','subject_id'=>$airport->id,'field'=>$data['fuel_type'],'before_price'=>$current,'after_price'=>$next,'context'=>json_encode(['label'=>$airport->icao.' — '.$airport->name,'country'=>$airport->country,'region'=>$airport->region,'operation'=>$data['mode'],'value'=>$data['value']]),'created_at'=>now(),'updated_at'=>now()]);
                $updated++;
            }
            return $updated;
        });
        return redirect()->route('admin.promethee.economy')->with('success','Prix carburant mis à jour pour '.$count.' aéroport(s).');
    }
    public function preview(Request $r,EconomyService $service) {
        $d=$r->validate([
            'target'=>'required|in:ticket,fuel','mode'=>'required|in:percent,add,set','value'=>'required|numeric|between:-999999,999999',
            'location'=>'nullable|string|max:191','region'=>'nullable|string|max:191','country'=>'nullable|string|size:2','airport_id'=>'nullable|exists:airports,id',
            'airline_id'=>'nullable|exists:airlines,id','fare_id'=>'required_if:target,ticket|nullable|exists:fares,id',
            'arrival_country'=>'nullable|string|size:2','subfleet_id'=>'nullable|exists:subfleets,id','distance_min'=>'nullable|numeric|min:0','distance_max'=>'nullable|numeric|gte:distance_min','include_inactive'=>'nullable|boolean',
            'fuel_type'=>'required|in:fuel_jeta_cost,fuel_100ll_cost,fuel_mogas_cost',
            'band'=>'required|in:keep,bleu,blanc,rouge','blue_percent'=>'required|numeric|between:1,100','white_percent'=>'required|numeric|between:1,100',
        ]);
        $r->session()->put('promethee.preview',$service->preview($d)+['expires'=>time()+900]);
        return redirect()->to(route('admin.promethee.economy').'#preview');
    }
    public function apply(Request $r,EconomyService $service) {
        $preview=$r->session()->get('promethee.preview');
        abort_unless($preview && $preview['expires']>=time(),419,'Aperçu expiré. Refaire la simulation.');
        $id=$service->apply($preview,$r->user()->id);
        if (!empty($preview['rule_id'])) DB::table('promethee_pricing_rules')->where('id',$preview['rule_id'])->update(['last_applied_at'=>now(),'updated_at'=>now()]);
        $r->session()->forget('promethee.preview');
        return redirect()->route('admin.promethee.economy')->with('success','Modification nº '.$id.' appliquée. Les anciens PIREP n’ont pas été recalculés.');
    }
    public function revert(int $id,EconomyService $service) {
        $service->revert($id);
        return back()->with('success','Tarifs précédents restaurés.');
    }
    public function safety(Request $r,BulletinService $service) {
        $month=$this->month($r);
        $saved=DB::table('promethee_bulletins')->where('month',$month)->first();
        return $this->page('safety',['report'=>$saved ? json_decode($saved->report,true) : $service->build($month),'month'=>$month,'saved'=>$saved]);
    }
    public function generate(Request $r,BulletinService $service) {
        $d=$r->validate(['month'=>'required|date_format:Y-m']);
        $service->save($d['month']);
        return redirect()->route('promethee.safety',$d)->with('success','Bulletin enregistré. Prêt à exporter, aucun envoi effectué.');
    }
    public function export(Request $r,BulletinService $service) {
        $month=$this->month($r);
        $saved=DB::table('promethee_bulletins')->where('month',$month)->first();
        $report=$saved ? json_decode($saved->report,true) : $service->build($month);
        return response()->streamDownload(function () use ($report) {
            $out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");
            fputcsv($out,['Mois','Indicateur','Valeur'],';');
            foreach ($report as $k=>$v) {
                if (is_array($v)) foreach ($v as $key=>$value) fputcsv($out,[$report['month'],$k.'.'.$key,$value],';');
                else fputcsv($out,[$report['month'],$k,$v],';');
            }
            fclose($out);
        },'AIR-INTER-BULLETIN-'.$month.'.csv',['Content-Type'=>'text/csv; charset=UTF-8']);
    }
    public function acars(Request $r) {
        return $this->page('acars',[
            'bids'=>DB::table('bids')->where('user_id',$r->user()->id)->count(),
            'recent'=>Pirep::where('user_id',$r->user()->id)->orderByDesc('created_at')->limit(8)->get(),
        ]);
    }
    public function adminDashboard(Request $r) {
        $monthStart = now()->startOfMonth();
        return $this->page('admin.dashboard', [
            'activePilots' => User::where('state', UserState::ACTIVE)->count(),
            'newPilots' => User::where('created_at', '>=', $monthStart)->count(),
            'pendingPireps' => Pirep::where('state', PirepState::PENDING)->count(),
            'acceptedPireps' => Pirep::where('state', PirepState::ACCEPTED)->where('submitted_at','>=',$monthStart)->count(),
            'rejectedPireps' => Pirep::where('state', PirepState::REJECTED)->where('submitted_at','>=',$monthStart)->count(),
            'flightMinutes' => (int) Pirep::where('state', PirepState::ACCEPTED)->sum('flight_time'),
            'activeEvents' => DB::table('promethee_events')->where('ends_at','>=',now())->count(),
            'recentProgression' => DB::table('promethee_progression_history')->latest()->limit(8)->get(),
            'activeMissions' => DB::table('promethee_missions')->where('active',true)->count(),
            'activeCircuits' => DB::table('promethee_circuits')->where('active',true)->count(),
            'monthlyAssignments' => DB::table('promethee_assignments')->where('month',now('Europe/Paris')->format('Y-m'))->count(),
            'shopItems' => DB::table('promethee_shop_items')->where('active',true)->count(),
            'pendingTransfers' => DB::table('promethee_transfer_requests')->whereIn('type',['hub','airline'])->where('status','pending')->count(),
            'jumpseatCount' => DB::table('promethee_transfer_requests')->where('type','jumpseat')->count(),
        ]);
    }
    public function automation() {
        $badgeRules = DB::table('promethee_badge_rules')->orderByDesc('updated_at')->get();
        $rankRules = DB::table('promethee_rank_rules')->orderByDesc('updated_at')->get();
        return $this->page('admin.automation', [
            'badgeRules' => $badgeRules,
            'rankRules' => $rankRules,
            'badgeRuleData' => $badgeRules->groupBy('award_id')->map(fn ($rules) => $this->rulePayload($rules->first())),
            'rankRuleData' => $rankRules->groupBy('rank_id')->map(fn ($rules) => $this->rulePayload($rules->first())),
            'awards' => Award::orderBy('name')->get(), 'ranks' => Rank::orderBy('hours')->get(),
            'awardData' => Award::orderBy('name')->get()->mapWithKeys(fn ($award) => [$award->id => ['name'=>$award->name, 'description'=>$award->description, 'image_url'=>$award->image_url]]),
            'rankData' => Rank::orderBy('hours')->get()->mapWithKeys(fn ($rank) => [$rank->id => ['name'=>$rank->name, 'hours'=>$rank->hours, 'image_url'=>$rank->image_url]]),
            'airlines' => Airline::where('active', true)->orderBy('name')->get(['id','name','icao']),
            'aircraftTypes' => \App\Models\Aircraft::whereNotNull('icao')->where('icao', '!=', '')->distinct()->orderBy('icao')->pluck('icao'),
            'events' => DB::table('promethee_events')->orderByDesc('starts_at')->limit(100)->get(['id','title','starts_at']),
            'airlines' => Airline::orderBy('name')->get(['id','name','icao']),
            'events' => DB::table('promethee_events')->orderByDesc('starts_at')->get(['id','title','starts_at']),
            'history' => DB::table('promethee_progression_history')->latest()->limit(30)->get(),
        ]);
    }
    private function rulePayload(object $rule): array {
        return ['id'=>$rule->id, 'operator'=>$rule->operator, 'criteria'=>json_decode($rule->criteria, true) ?: [], 'active'=>(bool)$rule->active, 'allow_demotion'=>(bool)($rule->allow_demotion ?? false)];
    }
    public function automationRule(string $kind, int $id) {
        $table = $kind === 'badge' ? 'promethee_badge_rules' : 'promethee_rank_rules';
        $column = $kind === 'badge' ? 'award_id' : 'rank_id';
        $rule = DB::table($table)->where($column, $id)->orderByDesc('updated_at')->first();
        return response()->json($rule ? $this->rulePayload($rule) : null);
    }
    public function recalculateAutomation(Request $r, \Modules\Promethee\Services\ProgressionService $progression) {
        $result = $progression->recalculate(null, 'manual');
        return back()->with('success', $result['awards'].' badge(s) et '.$result['promotions'].' promotion(s) attribué(e)(s).');
    }
    private function automationCriteria(Request $r): array {
        $data = $r->validate(['operator'=>'required|in:and,or','criteria'=>'required|array|min:1|max:12','criteria.*.metric'=>'required|string','criteria.*.value'=>'nullable','criteria.*.text'=>'nullable|string|max:30']);
        $criteria = $data['criteria'];
        $metrics = ['validated_flights','flight_minutes','total_distance','visited_airports','visited_countries','seniority_days','required_badge','route','airline','aircraft_icao','event_completed','night_flights'];
        foreach ($criteria as &$criterion) {
            abort_unless(is_array($criterion) && in_array($criterion['metric'] ?? null, $metrics, true), 422, 'Critère non valide.');
            $criterion['value'] = isset($criterion['value']) ? (float) $criterion['value'] : 0;
            $criterion['route'] = $criterion['metric'] === 'route' ? strtoupper(substr((string)($criterion['text'] ?? ''), 0, 30)) : null;
            $criterion['text'] = $criterion['metric'] === 'aircraft_icao' ? strtoupper(substr((string)($criterion['text'] ?? ''), 0, 30)) : null;
        }
        return [$data['operator'], $criteria];
    }
    private function distinctionImage(Request $r): ?string {
        if ($r->hasFile('image')) {
            // Public assets are replaced whenever the local image is rebuilt.
            // Keep uploads on Laravel's persistent storage volume and expose
            // that directory through the stable public symlink created at boot.
            $file=$r->file('image'); $directory=storage_path('app/promethee-distinctions');
            File::ensureDirectoryExists($directory);
            $name=uniqid('distinction_', true).'.'.$file->extension(); $file->move($directory,$name);
            return '/promethee-assets/distinctions/'.$name;
        }
        return $r->filled('image_url') ? $r->string('image_url')->toString() : null;
    }
    public function createAutomationAward(Request $r) {
        $d=$r->validate(['name'=>'required|string|max:191','description'=>'nullable|string|max:1000','image_url'=>'nullable|url|max:2000','image'=>'nullable|image|max:4096']);
        $d['image_url']=$this->distinctionImage($r); unset($d['image']);
        Award::create($d+['active'=>true]);
        return back()->with('success','Badge ajouté au catalogue.');
    }
    public function createAutomationRank(Request $r) {
        $d=$r->validate(['name'=>'required|string|max:50|unique:ranks,name','hours'=>'required|integer|min:0','image_url'=>'nullable|url|max:2000','image'=>'nullable|image|max:4096']);
        $d['image_url']=$this->distinctionImage($r); unset($d['image']);
        Rank::create($d);
        return back()->with('success','Grade ajouté au catalogue.');
    }
    public function updateAutomationAward(Request $r, Award $award) {
        $data=$r->validate(['name'=>'required|string|max:191','description'=>'nullable|string|max:1000','image_url'=>'nullable|url|max:2000','image'=>'nullable|image|max:4096']);
        $image=$r->hasFile('image') || $r->filled('image_url') ? $this->distinctionImage($r) : $award->image_url;
        $award->update(['name'=>$data['name'],'description'=>$data['description'] ?? null,'image_url'=>$image]);
        return back()->with('success', 'Badge mis à jour.');
    }
    public function updateAutomationRank(Request $r, Rank $rank) {
        $data=$r->validate(['name'=>'required|string|max:50|unique:ranks,name,'.$rank->id,'hours'=>'required|integer|min:0','image_url'=>'nullable|url|max:2000','image'=>'nullable|image|max:4096']);
        $image=$r->hasFile('image') || $r->filled('image_url') ? $this->distinctionImage($r) : $rank->image_url;
        $rank->update(['name'=>$data['name'],'hours'=>$data['hours'],'image_url'=>$image]);
        return back()->with('success', 'Grade mis à jour.');
    }
    public function previewAutomation(Request $r, \Modules\Promethee\Services\ProgressionService $progression) {
        [$operator, $criteria] = $this->automationCriteria($r);
        $rule = ['operator' => $operator, 'criteria' => $criteria];
        $pilots = User::where('state', UserState::ACTIVE)->get()->filter(fn ($user) => $progression->eligible($user, $rule))->take(100)->values();
        return back()->with('automation_preview', ['count'=>$pilots->count(), 'pilots'=>$pilots->map(fn($pilot)=>$pilot->pilot_id.' · '.$pilot->name)->all()]);
    }
    public function saveBadgeRule(Request $r) {
        $data = $r->validate(['award_id'=>'required|integer|exists:awards,id','rule_id'=>'nullable|integer|exists:promethee_badge_rules,id','active'=>'nullable|boolean']); [$operator,$criteria] = $this->automationCriteria($r);
        $payload=['award_id'=>$data['award_id'],'operator'=>$operator,'criteria'=>json_encode($criteria),'active'=>$r->boolean('active'),'updated_at'=>now()];
        if (!empty($data['rule_id'])) DB::table('promethee_badge_rules')->where('id',$data['rule_id'])->update($payload); else DB::table('promethee_badge_rules')->insert($payload+['created_at'=>now()]);
        return back()->with('success','Règle de badge enregistrée.');
    }
    public function saveRankRule(Request $r) {
        $data = $r->validate(['rank_id'=>'required|integer|exists:ranks,id','rule_id'=>'nullable|integer|exists:promethee_rank_rules,id','active'=>'nullable|boolean','allow_demotion'=>'nullable|boolean']); [$operator,$criteria] = $this->automationCriteria($r);
        $payload=['rank_id'=>$data['rank_id'],'operator'=>$operator,'criteria'=>json_encode($criteria),'active'=>$r->boolean('active'),'allow_demotion'=>$r->boolean('allow_demotion'),'updated_at'=>now()];
        if (!empty($data['rule_id'])) DB::table('promethee_rank_rules')->where('id',$data['rule_id'])->update($payload); else DB::table('promethee_rank_rules')->insert($payload+['created_at'=>now()]);
        return back()->with('success','Règle de grade enregistrée.');
    }
    public function branding(BrandingService $branding) {
        return view('promethee::admin.branding', ['logos' => $branding->logos(), 'branding' => $branding->active()]);
    }
    public function saveBranding(Request $r, BrandingService $branding) {
        $data = $r->validate(['logo' => 'required|string|in:'.implode(',', array_keys($branding->logos()))]);
        $branding->save($data['logo']);
        return redirect()->route('admin.identity.branding')->with('success', 'Le logo Air Inter a été mis à jour.');
    }
    public function adminMissions() {
        return $this->page('admin-missions', [
            'missions'=>DB::table('promethee_missions')->orderByDesc('created_at')->get(),
            'circuits'=>DB::table('promethee_circuits')->orderByDesc('created_at')->get()->map(function($circuit){ $circuit->legs=DB::table('promethee_circuit_legs')->where('circuit_id',$circuit->id)->orderBy('position')->get(); return $circuit; }),
            'flights'=>Flight::where('active',true)->where('visible',true)->orderBy('route_code')->orderBy('flight_number')->limit(200)->get(['id','route_code','flight_number','dpt_airport_id','arr_airport_id']),
        ]);
    }
    public function saveMission(Request $r) {
        $data=$r->validate(['title'=>'required|string|max:160','description'=>'nullable|string|max:5000','dpt_airport_id'=>'nullable|string|max:8','arr_airport_id'=>'nullable|string|max:8','flight_id'=>'nullable|string|max:36','starts_on'=>'nullable|date','ends_on'=>'nullable|date|after_or_equal:starts_on','active'=>'nullable|boolean']);
        DB::table('promethee_missions')->insert(['created_by'=>$r->user()->id,'title'=>$data['title'],'description'=>$data['description'] ?? null,'dpt_airport_id'=>strtoupper($data['dpt_airport_id'] ?? '') ?: null,'arr_airport_id'=>strtoupper($data['arr_airport_id'] ?? '') ?: null,'flight_id'=>$data['flight_id'] ?? null,'starts_on'=>$data['starts_on'] ?? null,'ends_on'=>$data['ends_on'] ?? null,'active'=>$r->boolean('active'),'created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','Mission publiée.');
    }
    public function deleteMission(int $id) { DB::table('promethee_missions')->where('id',$id)->delete(); return back()->with('success','Mission supprimée.'); }
    public function saveCircuit(Request $r) {
        $data=$r->validate(['title'=>'required|string|max:160','description'=>'nullable|string|max:5000','starts_on'=>'nullable|date','ends_on'=>'nullable|date|after_or_equal:starts_on','active'=>'nullable|boolean','legs'=>'required|array|min:1|max:30','legs.*.departure'=>'required|string|max:8','legs.*.arrival'=>'required|string|max:8','legs.*.flight_id'=>'nullable|string|max:36']);
        $id=DB::table('promethee_circuits')->insertGetId(['created_by'=>$r->user()->id,'title'=>$data['title'],'description'=>$data['description'] ?? null,'starts_on'=>$data['starts_on'] ?? null,'ends_on'=>$data['ends_on'] ?? null,'active'=>$r->boolean('active'),'created_at'=>now(),'updated_at'=>now()]);
        foreach($data['legs'] as $position=>$leg) DB::table('promethee_circuit_legs')->insert(['circuit_id'=>$id,'position'=>$position+1,'dpt_airport_id'=>strtoupper($leg['departure']),'arr_airport_id'=>strtoupper($leg['arrival']),'flight_id'=>$leg['flight_id'] ?? null,'created_at'=>now(),'updated_at'=>now()]);
        return back()->with('success','Circuit publié.');
    }
    public function deleteCircuit(int $id) { DB::table('promethee_circuit_legs')->where('circuit_id',$id)->delete(); DB::table('promethee_circuits')->where('id',$id)->delete(); return back()->with('success','Circuit supprimé.'); }
    public function adminAssignments(Request $r) {
        $month=$r->query('month',now('Europe/Paris')->format('Y-m'));
        $assignments=DB::table('promethee_assignments as assignment')->join('users','users.id','=','assignment.user_id')->join('flights','flights.id','=','assignment.flight_id')->where('assignment.month',$month)->select('assignment.*','users.name as user_name','users.pilot_id','flights.route_code','flights.flight_number','flights.dpt_airport_id','flights.arr_airport_id')->orderBy('users.pilot_id')->get();
        return $this->page('admin-assignments',['month'=>$month,'assignments'=>$assignments,'pilots'=>User::where('state',UserState::ACTIVE)->orderBy('pilot_id')->get(['id','pilot_id','name']),'flights'=>Flight::where('active',true)->where('visible',true)->orderBy('dpt_airport_id')->get(['id','route_code','flight_number','dpt_airport_id','arr_airport_id'])]);
    }
    public function adminPassport() { return $this->page('admin-passport',['enabled'=>DB::table('promethee_settings')->where('key','passport.enabled')->value('value') !== '0','showMap'=>DB::table('promethee_settings')->where('key','passport.map_enabled')->value('value') !== '0']); }
    public function savePassportSettings(Request $r) { $r->validate(['enabled'=>'nullable|boolean','map_enabled'=>'nullable|boolean']); foreach(['passport.enabled'=>$r->boolean('enabled'),'passport.map_enabled'=>$r->boolean('map_enabled')] as $key=>$value) DB::table('promethee_settings')->updateOrInsert(['key'=>$key],['value'=>$value?'1':'0','created_at'=>now(),'updated_at'=>now()]); return back()->with('success','Paramètres du passeport enregistrés.'); }
    public function saveAssignment(Request $r) { $data=$r->validate(['user_id'=>'required|integer|exists:users,id','flight_id'=>'required|string|exists:flights,id','month'=>'required|date_format:Y-m','notes'=>'nullable|string|max:2000']); DB::table('promethee_assignments')->updateOrInsert(['user_id'=>$data['user_id'],'flight_id'=>$data['flight_id'],'month'=>$data['month']],['notes'=>$data['notes']??null,'assigned_by'=>$r->user()->id,'updated_at'=>now(),'created_at'=>now()]); return back()->with('success','Affectation enregistrée.'); }
    public function deleteAssignment(int $id) { DB::table('promethee_assignments')->where('id',$id)->delete(); return back()->with('success','Affectation supprimée.'); }
    public function adminShop() { return $this->page('admin-shop',['items'=>DB::table('promethee_shop_items')->latest()->get(),'pilots'=>User::where('state',UserState::ACTIVE)->orderBy('pilot_id')->get(['id','pilot_id','name']),'wallets'=>DB::table('promethee_wallets as wallet')->join('users','users.id','=','wallet.user_id')->select('wallet.*','users.pilot_id','users.name')->orderByDesc('wallet.balance')->get()]); }
    public function saveShopItem(Request $r) { $data=$r->validate(['name'=>'required|string|max:160','description'=>'nullable|string|max:5000','price'=>'required|numeric|min:0|max:1000000','active'=>'nullable|boolean']); DB::table('promethee_shop_items')->insert(['name'=>$data['name'],'description'=>$data['description'] ?? null,'price'=>Money::convertToSubunit($data['price']),'active'=>$r->boolean('active'),'created_at'=>now(),'updated_at'=>now()]); return back()->with('success','Article ajouté au catalogue.'); }
    public function creditWallet(Request $r, FinanceService $finance) { $data=$r->validate(['user_id'=>'required|integer|exists:users,id','amount'=>'required|numeric|between:-100000,100000']); $user=User::with('journal')->findOrFail($data['user_id']); $amount=new Money(Money::convertToSubunit(abs($data['amount']))); if($data['amount']>=0)$finance->creditToJournal($user->journal,$amount,$user,'Crédit boutique Prométhée','shop','shop'); else { if((int)$user->journal->getBalance()->getAmount()<(int)$amount->getAmount()) return back()->withErrors(['amount'=>'Solde phpVMS insuffisant pour ce débit.']); $finance->debitFromJournal($user->journal,$amount,$user,'Débit boutique Prométhée','shop','shop'); } return back()->with('success','Journal phpVMS du pilote mis à jour.'); }
    public function adminTransfers() { return $this->page('admin-transfers',['requests'=>DB::table('promethee_transfer_requests as request')->join('users','users.id','=','request.user_id')->leftJoin('airlines','airlines.id','=','request.target_airline_id')->leftJoin('airports','airports.id','=','request.target_airport_id')->select('request.*','users.name as user_name','users.pilot_id','airlines.name as airline_name','airports.name as airport_name')->latest('request.created_at')->get()]); }
    public function adminJumpseats() { return $this->page('admin-jumpseats',['requests'=>DB::table('promethee_transfer_requests as request')->join('users','users.id','=','request.user_id')->leftJoin('airports','airports.id','=','request.target_airport_id')->where('request.type','jumpseat')->select('request.*','users.name as user_name','users.pilot_id','airports.icao','airports.name as airport_name')->latest('request.created_at')->get(),'basePrice'=>(float) (DB::table('promethee_settings')->where('key','jumpseat.base_price')->value('value') ?: 0.13)]); }
    public function saveJumpseatSettings(Request $r) { $data=$r->validate(['base_price'=>'required|numeric|min:0|max:10000']); DB::table('promethee_settings')->updateOrInsert(['key'=>'jumpseat.base_price'],['value'=>$data['base_price'],'updated_at'=>now(),'created_at'=>now()]); return back()->with('success','Tarif de base du jumpseat enregistré.'); }
    public function decideTransfer(int $id, Request $r) { $data=$r->validate(['status'=>'required|in:approved,rejected','decision_note'=>'nullable|string|max:2000']); $request=DB::table('promethee_transfer_requests')->where('id',$id)->where('status','pending')->first(); abort_unless($request,404); DB::transaction(function() use($request,$data,$r){ if($data['status']==='approved'){ if($request->type==='airline') User::where('id',$request->user_id)->update(['airline_id'=>$request->target_airline_id]); elseif($request->type==='hub') User::where('id',$request->user_id)->update(['home_airport_id'=>$request->target_airport_id]); } DB::table('promethee_transfer_requests')->where('id',$request->id)->update(['status'=>$data['status'],'decision_note'=>$data['decision_note']??null,'decided_by'=>$r->user()->id,'decided_at'=>now(),'updated_at'=>now()]); }); return back()->with('success',$request->type==='jumpseat' ? 'Décision de jumpseat enregistrée.' : 'Décision de transfert enregistrée.'); }
}
